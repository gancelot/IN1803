"""

    api.py

    There are two users: john / password who is a regular user, and
                         admin / admin who is a privileged user.

"""
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Annotated

import jwt
import uvicorn
from fastapi import Depends, FastAPI, Form, HTTPException, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jwt.exceptions import InvalidTokenError
from passlib.context import CryptContext
from pydantic import BaseModel
from sqlalchemy import create_engine, Column
from sqlalchemy.orm import declarative_base, sessionmaker
from sqlalchemy.types import Boolean, Float, Integer, String

db_url = Path(__file__).parents[1] / 'data/course_data.db'
if not db_url.exists():
    print(f'Database file does not exist at: {db_url}--exiting.', file=sys.stderr)
    sys.exit(1)

engine = create_engine('sqlite:///' + str(db_url), echo=True)
Session = sessionmaker(bind=engine)
session = Session()

Base = declarative_base()

# Run command: openssl rand -hex 32 or pip install binascii and run binascii.hexlify(os.urandom(24))
SECRET_KEY = '33a71f908cfa5dd3709d923412a6b7654b34e1276e5e3b2add1bc45c21f1a6b4'
ALGORITHM = 'HS256'
TOKEN_EXPIRATION = 30


class JWTBearer(HTTPBearer):
    def __init__(self, auto_error: bool = True):
        super().__init__(auto_error=auto_error)

    async def __call__(self, request: Request):
        creds: HTTPAuthorizationCredentials = await super().__call__(request)
        if creds:
            if not creds.scheme == 'Bearer':
                raise HTTPException(status_code=403, detail='Invalid authentication scheme.')
            if not self.verify_token(creds.credentials):
                raise HTTPException(status_code=403, detail='Invalid token or expired token.')
            return creds.credentials
        else:
            raise HTTPException(status_code=403, detail='Invalid authorization code.')

    def verify_token(self, jwtoken: str) -> bool:
        token_valid: bool = False

        try:
            decode_token(jwtoken)
            token_valid = True
        except Exception:
            pass

        return token_valid


class Token(BaseModel):
    access_token: str
    token_type: str


class TokenData(BaseModel):
    username: str | None = None


class AuthCredentials(BaseModel):
    username: str | None = None
    password: str | None = None


class User(BaseModel):
    username: str
    email: str | None = None
    full_name: str | None = None
    admin: bool = False


class UserInDB(User):
    hashed_password: str


class UserInDBModel(Base):
    __tablename__ = 'user_auth'
    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String(50))
    full_name = Column(String(100))
    email = Column(String(100))
    hashed_password = Column('password', String(300))
    admin = Column(Boolean)

    def to_dict(self) -> dict:
        return {'id': self.id, 'username': self.username, 'full_name': self.full_name,
                'email': self.email, 'hashed_password': self.hashed_password, 'admin': self.admin}


class CelebrityModel(Base):
    __tablename__ = 'celebrity'
    id = Column('id', Integer, primary_key=True, autoincrement=True)
    name = Column(String(100))
    pay = Column(Float)
    year = Column(String(15))
    category = Column(String(50))

    def __init__(self, name: str, pay: float, year: str, category: str, **kwargs):
        super().__init__(**kwargs)
        self.name = name
        self.pay = pay
        self.year = year
        self.category = category

    def __str__(self):
        return f'{self.year} {self.name} {self.pay} {self.category}'

    def to_dict(self) -> dict:
        return {'id': self.id, 'name': self.name, 'pay': self.pay,
                'year': self.year, 'category': self.category}

    __repr__ = __str__


pwd_context = CryptContext(schemes=['bcrypt'], deprecated='auto')

app = FastAPI()


def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)


def get_password_hash(password: str):
    return pwd_context.hash(password)


def get_user(username: str):
    user = session.query(UserInDBModel).filter(UserInDBModel.username == username).first()
    if user:
        return UserInDB(**user.to_dict())


def authenticate_user(username: str, password: str):
    user = get_user(username)
    if not user:
        return False
    if not verify_password(password, user.hashed_password):
        return False
    return user


def encode_token(data_to_encode, secret_key: str = SECRET_KEY, algorithm: str = ALGORITHM) -> str:
    return jwt.encode(data_to_encode, secret_key, algorithm)


def decode_token(token, secret_key: str = SECRET_KEY, algorithm: str = ALGORITHM):
    return jwt.decode(token, secret_key, algorithms=[algorithm])


def create_access_token(data: dict, expires_delta: timedelta | None = None):
    to_encode = data.copy()
    if not expires_delta:
        expires_delta = timedelta(minutes=TOKEN_EXPIRATION)

    expire = datetime.now(timezone.utc) + expires_delta
    to_encode.update({"exp": expire})

    return encode_token(to_encode)


async def get_current_user(token: Annotated[str, Depends(JWTBearer())]):
    credentials_exception = HTTPException(status_code=401, detail='Could not validate credentials',
                                          headers={'WWW-Authenticate': 'Bearer'})
    try:
        payload = decode_token(token)
        username: str = payload.get('sub')
        if not username:
            raise credentials_exception
        token_data = TokenData(username=username)
    except InvalidTokenError:
        raise credentials_exception
    user = get_user(username=token_data.username)
    if user is None:
        raise credentials_exception
    return user


async def get_current_active_user(current_user: Annotated[User, Depends(get_current_user)]):
    return current_user


@app.post('/login')
async def login_for_access_token(form_data: Annotated[AuthCredentials, Form()]) -> Token:
    user = authenticate_user(form_data.username, form_data.password)

    if not user:
        raise HTTPException(status_code=401, detail='Incorrect login.', headers={'WWW-Authenticate': 'Bearer'})

    access_token = create_access_token(data={'sub': user.username}, expires_delta=timedelta(minutes=TOKEN_EXPIRATION))
    return Token(access_token=access_token, token_type='bearer')


@app.get('/api/celebrities/{name}')
async def get_all_celebrities(current_user: Annotated[User, Depends(get_current_active_user)],
                              name: str, limit: int = 5, page: int = 0):
    celebs = session.query(CelebrityModel).filter(CelebrityModel.name.contains(name)).limit(limit).offset(page * limit).all()

    if not celebs:
        raise HTTPException(status_code=404, detail=f'No celebrities found.')
    return {'current_user': current_user.username, f'page{page}_results': celebs}

uvicorn.run(app, host='localhost', port=8000)
