"""

    main.py

    There are two users: john / password who is a regular user, and
                         admin / admin who is a privileged user.

"""
import uvicorn

from app import app

uvicorn.run(app, host='localhost', port=8000)
