from sqlalchemy import Column
from sqlalchemy.orm import declarative_base
from sqlalchemy.types import Boolean, Float, Integer, String

Base = declarative_base()


class UserInDBModel(Base):
    __tablename__ = 'user_auth'
    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String(50))
    full_name = Column(String(100))
    email = Column(String(100))
    hashed_password = Column('password', String(300))
    admin = Column(Boolean)

    def to_dict(self) -> dict:
        return {'id': self.id, 'username': self.username, 'full_name': self.full_name,
                'email': self.email, 'hashed_password': self.hashed_password, 'admin': self.admin}


class CelebrityModel(Base):
    __tablename__ = 'celebrity'
    id = Column('id', Integer, primary_key=True, autoincrement=True)
    name = Column(String(100))
    pay = Column(Float)
    year = Column(String(15))
    category = Column(String(50))

    def __init__(self, name: str, pay: float, year: str, category: str, **kwargs):
        super().__init__(**kwargs)
        self.name = name
        self.pay = pay
        self.year = year
        self.category = category

    def __str__(self):
        return f'{self.year} {self.name} {self.pay} {self.category}'

    def to_dict(self) -> dict:
        return {'id': self.id, 'name': self.name, 'pay': self.pay,
                'year': self.year, 'category': self.category}

    __repr__ = __str__
