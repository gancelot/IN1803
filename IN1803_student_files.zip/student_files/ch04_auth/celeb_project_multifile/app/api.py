"""

    api.py

    Our user database is simulated below as a dictionary.
    There are two users: john / password who is a regular user, and
                         admin / admin who is a privileged user.

"""
from datetime import timedelta
from typing import Annotated

from decouple import config
from fastapi import Depends, FastAPI, Form, HTTPException

from .db_config import session
from .auth import authenticate_user, create_access_token, get_current_active_user
from .auth_models import AuthCredentials, User, Token
from .db_models import CelebrityModel

app = FastAPI()

TOKEN_EXPIRATION = config('TOKEN_EXPIRATION', cast=int)


@app.post('/login')
async def login_for_access_token(form_data: Annotated[AuthCredentials, Form()]) -> Token:
    user = authenticate_user(form_data.username, form_data.password)

    if not user:
        raise HTTPException(status_code=401, detail='Incorrect login.', headers={'WWW-Authenticate': 'Bearer'})

    access_token = create_access_token(data={'sub': user.username}, expires_delta=timedelta(minutes=TOKEN_EXPIRATION))
    return Token(access_token=access_token, token_type='bearer')


@app.get('/api/celebrities/{name}')
async def get_all_celebrities(current_user: Annotated[User, Depends(get_current_active_user)],
                              name: str, limit: int = 5, page: int = 0):
    celebs = session.query(CelebrityModel).filter(CelebrityModel.name.contains(name)).limit(limit).offset(page * limit).all()

    if not celebs:
        raise HTTPException(status_code=404, detail=f'No celebrities found.')
    return {'current_user': current_user.username, f'page{page}_results': celebs}


@app.get('/api/celebrities/id/{celeb_id}')
async def get_one_celebrity(current_user: Annotated[User, Depends(get_current_active_user)],
                            celeb_id: int):
    celeb = session.get(CelebrityModel, celeb_id)
    if not celeb:
        raise HTTPException(status_code=404, detail=f'Celebrity not found.')
    return celeb.to_dict()
