import sys
from pathlib import Path

from decouple import config
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

STUDENT_FILES_DB_PATH = config('STUDENT_FILES_DB_PATH')

db_url = Path(__file__).parents[3] / STUDENT_FILES_DB_PATH
if not db_url.exists():
    print(f'Database file does not exist at: {db_url}--exiting.', file=sys.stderr)
    sys.exit(1)

engine = create_engine('sqlite:///' + str(db_url), echo=True)
Session = sessionmaker(bind=engine)
session = Session()
