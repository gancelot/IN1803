from pydantic import BaseModel


class Token(BaseModel):
    access_token: str
    token_type: str


class TokenData(BaseModel):
    username: str | None = None


class AuthCredentials(BaseModel):
    username: str | None = None
    password: str | None = None


class User(BaseModel):
    username: str
    email: str | None = None
    full_name: str | None = None
    admin: bool = False


class UserInDB(User):
    hashed_password: str
