from pydantic import BaseModel


class Celebrity(BaseModel):
    name: str = ''
    pay: float = 0.0
    year: str = ''
    category: str = ''
