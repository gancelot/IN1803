"""

    03_test_celeb_auth.py
    This client requires api.py
    to be running in order for this to work.

    Note: You may also test it in the auto-generated UI at localhost:8000/docs as follows:
    1. Select the GET /api/celebrities route and expand it.  Select Try It Out.  Click Execute.
       (it should fail)
    2. Select the POST /login route and expand it.  Supply admin / admin values.  Click Execute.
    3. Click Authorize in the upper right corner.
    4. Now, select the GET /api/celebrities route once again.  Click execute.  It should work!

"""
import click
import requests

host = 'http://localhost:8000'
path = '/api/celebrities/'

celebrity = click.prompt('Celebrity name to search for', default='Oprah', show_default=True)

print('Trying to access resource without any token:')
req1 = requests.get(f'{host}{path}{celebrity}')
print(req1.status_code, req1.text)

print('\nLogging in to /login with invalid credentials:')
req2 = requests.post(f'{host}/login', data={'username': 'admin', 'password': 'password'})
print(req2.status_code, req2.text)

print('\nLogging in to /login with valid credentials:')
req3 = requests.post(f'{host}/login', data={'username': 'admin', 'password': 'admin'})
print(req3.status_code, req3.text)
token = req3.json().get('access_token')

print('\nAccessing our resource again:')
req4 = requests.get(f'{host}{path}{celebrity}',
                    headers={'Authorization': f'Bearer {token}'},
                    params={'limit': 10})
print(req4.status_code, req4.text)
