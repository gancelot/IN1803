"""

    09_get_single_celebrity_error_handling.py

"""
from pathlib import Path

import uvicorn
from fastapi import FastAPI, HTTPException

data = [line.strip().split(',') for line in Path('../data/celebrity_100.csv').open(encoding='utf-8')][1:]
print('Celebrity data read.')

app = FastAPI()


@app.get('/api/celebrities/{name}')
def get_one_celebrity(name):
    results = [row for row in data if name.casefold() in row[0].casefold()]

    if not results:
        raise HTTPException(status_code=404, detail='Celebrity not found')

    return {'results': results, 'name': name}


uvicorn.run(app, host='localhost', port=8000)
