"""

    17_post_as_json_data.py

    This implements the POST method within FastAPI.  While not complete, it illustrates the method stub
    as if data was submitted as JSON (serialized) data in the body of the HTTP request.
    (Note: see the json= attribute of the POST request in the subsequent source file).

"""
from typing import Annotated

import uvicorn
from fastapi import Body, FastAPI

app = FastAPI()


@app.post('/api/celebrities')
async def create_celebrity(name: Annotated[str, Body()],
                     pay: Annotated[float, Body()],
                     year: Annotated[int, Body()],
                     category: Annotated[str, Body()]):
    return {'action': 'POST response',
            'name': name, 'pay': pay, 'year': year, 'category': category}


uvicorn.run(app, host='localhost', port=8000)
