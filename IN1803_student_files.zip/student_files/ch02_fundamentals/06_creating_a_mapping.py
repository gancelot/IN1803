"""

    06_creating_a_mapping.py

"""
from pathlib import Path

import uvicorn
from fastapi import FastAPI

data = [line.strip().split(',') for line in Path('../data/celebrity_100.csv').open(encoding='utf-8')][1:]
print('Celebrity data read.')

app = FastAPI()


@app.get('/api/celebrities/{name}')
def do_stuff(name):
    return f'Hi there {name}!'


uvicorn.run(app, host='localhost', port=8000)
