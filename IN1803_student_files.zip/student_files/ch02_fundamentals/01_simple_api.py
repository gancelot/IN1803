"""

    01_simple_api.py

"""
from flask import Flask


app = Flask(__name__)


app.run(host='localhost', port=8051)
