"""

    10_consuming_apis.py

"""
import click
import json
import requests

base_url = 'http://localhost:8000'
path = '/api/celebrities/'
default = 'Kevin'

celeb_name = click.prompt('Enter celebrity to find info about', default=default)

results = requests.get(f'{base_url}{path}{celeb_name}').json()
print(json.dumps(results, indent=4))
