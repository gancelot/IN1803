"""

    16_testing_post_as_form_send.py
    This source file should be used when running 15_post_as_form_data.py
    as the server.

"""
import requests

base_url = 'http://localhost:8000'
path = '/api/celebrities/'
celeb_name = 'Kevin'

print('posting:')
results = requests.post(f'{base_url}{path}'.strip('/'),
                        data={'name': celeb_name,
                              'category': 'Actors',
                              'pay': 3.0,
                              'year': 2024})
print(results.text)
print('Request body format:')
print(results.request.body)
