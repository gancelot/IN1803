"""

    13_python_type_hints.py

"""
from itertools import islice
from pathlib import Path

from pydantic import validate_call


class Celebrity:
    def __init__(self, name: str, pay: float, year: int, category: str):
        self.name = name
        self.pay = pay
        self.year = year
        self.category = category

    def __str__(self):
        return f'{self.year:<6}{self.name} ({self.category}) ${self.pay:>} million'

    __repr__ = __str__


@validate_call
def read_celebs(filepath: str | Path,
                size: int = 10,
                encoding: str = 'utf-8') -> list[Celebrity]:
    results = []
    with open(Path(filepath), encoding=encoding) as f:
        f.readline()
        for line in islice(f, size):
            values = line.strip().split(',')
            results.append(Celebrity(values[0], float(values[1]), int(values[2]), values[3]))

        return results


datafile = '../data/celebrity_100.csv'
print(read_celebs(datafile, 7))
print(read_celebs(size='7', filepath=datafile))
print(read_celebs(datafile, 'hello'))
