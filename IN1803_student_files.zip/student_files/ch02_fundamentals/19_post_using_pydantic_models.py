"""

    19_post_using_pydantic_models.py

    This implements the POST method within FastAPI.  While not complete, it illustrates the method stub
    as if data was submitted as JSON (serialized) data in the body of the HTTP request.
    (Note: see the json= attribute of the POST request in the subsequent source file).

    This version is optimized to use Pydantic models to capture the data into a Celebrity model object.
    Type validation is performed as well.
.

"""
from pathlib import Path

import uvicorn
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

data = [line.strip().split(',') for line in Path('../data/celebrity_100.csv').open(encoding='utf-8')][1:]
print('Celebrity data read.')

app = FastAPI()


class Celebrity(BaseModel):
    name: str
    pay: float
    year: int
    category: str


@app.get('/api/celebrities/{name}')
async def get_one_celebrity(name):
    results = [row for row in data if name.casefold() in row[0].casefold()]

    if not results:
        raise HTTPException(status_code=404, detail='Celebrity not found')

    return {'results': results, 'name': name}


@app.post('/api/celebrities')
async def create_celebrity(celebrity: Celebrity):
    return {'action': 'POST response', **celebrity.model_dump()}


@app.get('/api/celebrities')
async def get_all_celebrities():
    return {'action': 'GET (all) response'}


@app.put('/api/celebrities/{name}')
async def update_celebrity():
    return {'action': 'PUT response'}


@app.delete('/api/celebrities/{name}')
async def delete_celebrity():
    return {'action': 'DELETE response'}


uvicorn.run(app, host='localhost', port=8000)
