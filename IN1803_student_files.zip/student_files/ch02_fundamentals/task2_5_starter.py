"""

    task2_5_starter.py
    This version of the exercise adds SQLAlchemy to the Invoice API.

"""
import sys
from pathlib import Path

import uvicorn
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from sqlalchemy import create_engine, Column
from sqlalchemy.orm import declarative_base, sessionmaker
from sqlalchemy.types import Float, Integer, String

db_url = Path(__file__).parents[1] / 'data/course_data.db'
if not db_url.exists():
    print(f'Database file does not exist at: {db_url}--exiting.', file=sys.stderr)
    sys.exit()

app = FastAPI()

engine = create_engine('sqlite:///' + str(db_url), echo=True)

# Step 1. Create the Session class using sessionmaker() passing the engine in a bind= parameter
#         Also instantiate the Session calling it 'session'


# Step 2. Create the Base class using declarative_base()


class Invoice(BaseModel):
    invoice_num: str
    stock_code: str
    quantity: int
    description: str
    invoice_date: str
    unit_price: float
    customer_id: str
    country: str


# Step 3. Create the Invoice SQLAlchemy class in the blank line provide below.
#         Have it inherit from Base. Within the class, indicate the table it coordinates with.
#         To save time, the column definitions have been provided for us.  Uncomment these lines.

    # id = Column(Integer, primary_key=True, autoincrement=True)
    # invoice_num = Column('InvoiceNo', String(30))
    # stock_code = Column('StockCode', String(30))
    # quantity = Column(Integer)
    # description = Column(String(150))
    # invoice_date = Column('InvoiceDate', String(50))
    # unit_price = Column('UnitPrice', Float)
    # customer_id = Column('CustomerID', String(50))
    # country = Column(String(50))

# Step 4. Create an init that takes all of the above fields except the id (which is database generated).
# To save time, create the init below in the blank line and then uncomment the block of lines provided after that.

        # super().__init__()
        # self.invoice_num = invoice_num
        # self.stock_code = stock_code
        # self.quantity = quantity
        # self.description = description
        # self.invoice_date = invoice_date
        # self.unit_price = unit_price
        # self.customer_id = customer_id
        # self.country = country

    def __str__(self):
        return f'({self.invoice_num}) {self.stock_code} Qty: {self.quantity} - {self.description}'

    def to_dict(self) -> dict:
        return {'id': self.id, 'invoice_num': self.invoice_num, 'stock_code': self.stock_code,
                'quantity': self.quantity, 'description': self.description, 'invoice_date': self.invoice_date,
                'unit_price': self.unit_price, 'customer_id': self.customer_id, 'country': self.country}

    __repr__ = __str__


@app.get('/api/invoices/{id}')
def retrieve_invoice(id: int):
    # Step 5. Remove the pass statement below.
    #         Implement the GET (one) method by using the session to get() the provided id.
    #         The syntax is session.get(Model, id)
    #         Check if invoice was found, if not raise an HTTPException(status_code=404, detail=f'Invoice not found")
    #         Return a dictionary of our model using the to_dict() method.
    pass


@app.post('/api/invoices')
def create_invoice(invoice_request: Invoice):
    # Step 6. Remove the pass statemenmt below.
    #         Implement the POST method by using the session.add() method.
    #         In the try block below, instantiate an InvoiceModel() passing
    #         **invoice_request.model_dump()
    #
    #         Call session.add() passing the new db invoice into it.
    try:
        pass
    except Exception as err:
        raise HTTPException(status_code=404, detail=f'Error creating invoice: {err.args[0]}')

    return results


@app.get('/api/invoices')
def get_all_invoices():
    return {'action': 'GET (all) response'}


@app.put('/api/invoices/{invoice_num}')
def update_invoice():
    return {'action': 'PUT response'}


@app.delete('/api/invoices/{invoice_num}')
def delete_invoice():
    return {'action': 'DELETE response'}


uvicorn.run(app, host='localhost', port=8000)
