"""

    12_classes.py

"""
import re
from pathlib import Path


class Celebrity:
    def __init__(self, name, pay, year, category):
        self.name = name
        self.pay = pay
        self.year = year
        self.category = category

    def __str__(self):
        return f'{self.year:<6}{self.name} ({self.category}) ${self.pay:>} million'


f = Path('../data/celebrity_100.csv').open(encoding='utf-8')
header = f.readline().strip().lower().split(',')
header[1] = re.sub(r'\([^()]*\)', '', header[1]).strip()  # remove parens, leaving: ['Name', 'Pay', 'Year', 'Category']

data = f.readline().strip().split(',')

data_dict = {h: d for h, d in zip(header, data)}

print(header)                                       # ['Name', 'Pay', 'Year', 'Category']
print(data)                                         # ['Oprah Winfrey', '225.0', '2005', 'Personalities']
print(data_dict)                                    # {'Name': 'Oprah Winfrey', 'Pay': '225.0',
                                                    #  'Year': '2005', 'Category': 'Personalities'}
celeb = Celebrity(**data_dict)
print(celeb)
