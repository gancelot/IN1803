"""

    22_testing_fastapi_sqlalchemy.py
    A FastAPI client.

"""
import requests

base_url = 'http://localhost:8000'
path = '/api/celebrities/'
single_path = 'id/'
celeb_name = 'Kevin'

print('\nGet all (for a partial name):')
r = requests.get(f'{base_url}{path}{celeb_name}')
results = r.json()
print(f'URL: {r.url}')
print(results)

celeb_id = results[0].get('id')
print(f'\nGet one (for id: {celeb_id})')
r = requests.get(f'{base_url}{path}{single_path}{celeb_id}')
print(f'URL: {r.url}')
results = r.json()
print(results)

print('\nPosting (creating a new celebrity):')
r = requests.post(f'{base_url}{path.rstrip("/")}',
                  json={'name': 'Mandalorian', 'category': 'Character', 'pay': 3.0, 'year': '2020'})
print(f'URL: {r.url}')
results = r.json()
print(results)

print('\nPutting (modifying our new celeb):')
r = requests.put(f'{base_url}{path}{single_path}{results.get('id')}',
                 json={'name': 'Boba Fett', 'category': 'Character', 'pay': 5.0, 'year': '2021'})
print(f'URL: {r.url}')
results = r.json()
print(results)

print('\nDeleting (removing our new celeb):')
r = requests.delete(f'{base_url}{path}{single_path}{results.get('id')}')
print(f'URL: {r.url}')
results = r.json()
print(results)

celeb_id = 10000
print(f'\nBad ID: {celeb_id}')
r = requests.get(f'{base_url}{path}{single_path}{celeb_id}')
print(f'URL: {r.url}')
print(r.json())

print('\nGet all (for FakeCelebName):')
r = requests.get(f'{base_url}{path}FakeCelebName')
print(f'URL: {r.url}')
print(r.json())
