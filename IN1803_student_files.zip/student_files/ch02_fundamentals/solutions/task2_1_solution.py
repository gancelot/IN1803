"""

    task2_1_solution.py

    To test this out, for now, simply use a browser.
    Start the server and browser to:
    http://localhost:8000/api/invoices/536365


"""
from pathlib import Path

import uvicorn
from fastapi import FastAPI, HTTPException


app = FastAPI()
data_file = '../../data/customer_purchases.csv'
data = [line.strip().split(',') for line in Path(data_file).open(encoding='unicode_escape')][1:]
print('Customer purchase data read.')


@app.get('/api/invoices/{invoice_num}')
async def retrieve_invoice(invoice_num):
    results = [row[1:] for row in data if invoice_num == row[0]]

    if not results:
        raise HTTPException(status_code=404, detail='Invoice not found')

    return {'results': results}


uvicorn.run(app, host='localhost', port=8000)
