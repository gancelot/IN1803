"""

    task2_3_solution.py

    This version of the exercise will add in additional functions to handle
     the POST, GET (all), PUT, and DELETE methods.  It will also create a
     Pydantic Invoice Model...

"""
from pathlib import Path

import uvicorn
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

data_file = '../../data/customer_purchases.csv'
data = [line.strip().split(',') for line in Path(data_file).open(encoding='unicode_escape')][1:]
print('Customer purchase data read.')

app = FastAPI()


class Invoice(BaseModel):
    stock_code: str
    quantity: int
    description: str
    invoice_date: str
    unit_price: float
    customer_id: str
    country: str


@app.get('/api/invoices/{invoice_num}')
async def retrieve_invoice(invoice_num):
    results = [row[1:] for row in data if invoice_num == row[0]]

    if not results:
        raise HTTPException(status_code=404, detail='Invoice not found')

    return {'results': results}


@app.post('/api/invoices')
async def create_invoice(invoice: Invoice):
    return {'action': 'POST response', **invoice.model_dump()}


@app.get('/api/invoices')
async def get_all_invoices():
    return {'action': 'GET (all) response'}


@app.put('/api/invoices/{invoice_num}')
async def update_invoice():
    return {'action': 'PUT response'}


@app.delete('/api/invoices/{invoice_num}')
async def delete_invoice():
    return {'action': 'DELETE response'}


uvicorn.run(app, host='localhost', port=8000)
