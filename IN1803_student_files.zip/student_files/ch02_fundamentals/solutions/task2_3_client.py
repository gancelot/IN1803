"""

    task2_3_client.py

"""
import requests

base_url = 'http://localhost:8000'
path = '/api/invoices/'
invoice_num = '536365'

results = requests.get(f'{base_url}{path}{invoice_num}')
print(results.text)

payload = {
    'stock_code': '20961',
    'quantity': 3,
    'description': 'STRAWBERRY BATH SPONGE',
    'invoice_date': '2/2/2022',
    'unit_price': 2.46,
    'customer_id': '17850',
    'country': 'United Kingdom'
}

print('posting:')
results = requests.post(f'{base_url}{path}'.rstrip('/'), json=payload)
print(results.text)

print('putting:')
results = requests.put(f'{base_url}{path}{invoice_num}')
print(results.text)

print('deleting:')
results = requests.delete(f'{base_url}{path}{invoice_num}')
print(results.text)

print('get all (100 invoices):')
results = requests.get(f'{base_url}{path}')
print(results.text)
