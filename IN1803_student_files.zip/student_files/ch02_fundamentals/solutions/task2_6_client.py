"""

    task2_6_client.py
    A FastAPI client for the task2_6_starter.py API implementation

"""
import requests

base_url = 'http://localhost:8000'
path = '/api/invoices/'

payload = {
    'invoice_num': '581590',
    'stock_code': '20961',
    'quantity': 3,
    'description': 'STRAWBERRY BATH SPONGE',
    'invoice_date': '2/2/2022',
    'unit_price': 2.46,
    'customer_id': '17850',
    'country': 'United Kingdom'
}

print('\nGet all (for a partial name):')
r = requests.get(f'{base_url}{path.rstrip('/')}')
results = r.json()
print(f'URL: {r.url}')
print(results)

invoice_id = results[0].get('id')
print(f'\nGet one (for invoice id: {invoice_id})')
r = requests.get(f'{base_url}{path}{invoice_id}')
print(f'URL: {r.url}')
results = r.json()
print(results)

print('\nPosting (adding a new invoice line item):')
r = requests.post(f'{base_url}{path.rstrip("/")}', json=payload)
print(f'URL: {r.url}')
results = r.json()
print(results)

print('\nPutting (modifying our newly added invoice line item):')
payload['quantity'] = 6
payload['unit_price'] = 3.50
r = requests.put(f'{base_url}{path}{results.get('id')}', json=payload)
print(f'URL: {r.url}')
results = r.json()
print(results)

print('\nDeleting (removing our new invoice line item):')
r = requests.delete(f'{base_url}{path}{results.get('id')}')
print(f'URL: {r.url}')
results = r.json()
print(results)

id = 1000000
print(f'\nBad invoice ID: {id}')
r = requests.get(f'{base_url}{path}{id}')
print(f'URL: {r.url}')
print(r.json())
