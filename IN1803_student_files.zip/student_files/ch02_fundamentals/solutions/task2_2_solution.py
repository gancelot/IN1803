"""

    task2_2_solution.py

"""
import json
from pprint import pprint

import click
import requests

base_url = 'http://localhost:8000'
path = '/api/invoices/'

default = '536365'
invoice_num = click.prompt('Enter invoice number to retrieve',
                           default=default)

results = requests.get(f'{base_url}{path}{invoice_num}').json()
pprint(results)
print(json.dumps(results, indent=4))
