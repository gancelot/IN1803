"""

    15_post_as_form_data.py

    This implements the POST method within FastAPI.  While not complete, it illustrates the method stub
    as if data was submitted as FORM data in the body of the HTTP request.
    (Note: see the data= attribute of the POST request in the subsequent source file).

"""
from typing import Annotated

import uvicorn
from fastapi import FastAPI, Form

app = FastAPI()


@app.post('/api/celebrities')
async def create_celebrity(name: Annotated[str, Form()],
                     pay: Annotated[float, Form()],
                     year: Annotated[int, Form()],
                     category: Annotated[str, Form()]):
    return {'action': 'POST response',
            'name': name, 'pay': pay, 'year': year, 'category': category}


uvicorn.run(app, host='localhost', port=8000)
