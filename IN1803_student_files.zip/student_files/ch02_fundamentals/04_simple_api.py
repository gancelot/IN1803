"""

    04_simple_api.py

"""
import uvicorn
from fastapi import FastAPI

app = FastAPI()

uvicorn.run(app, host='localhost', port=8000)
