"""

    01_coroutine.py - a simple initial asyncio execution, take note of the switching occurring

"""
import asyncio
import time


async def my_func(val: int):
    print(f'entering my_func {val}')
    await asyncio.sleep(1)
    print(f'exiting my_func {val}')


async def main():
    await asyncio.gather(my_func(1), my_func(2))

start = time.time()
asyncio.run(main())
print(f'Elapsed: {time.time() - start}')
