"""

    task2_2_starter.py

"""
import json

import requests
base_url = 'http://localhost:8051'
path = '/api/invoices/'

# Step 1. You may optionally prompt the user for the invoice number
#         To do this, use:
#                    invoice_num = input('Enter invoice number: ')

# Step 2. Construct the URL to access the API resource.  Include the server, path, and invoice number

# Step 3. Use requests to make a request to the server using the URL from step 2.  Perform a .json()
#         on the returned results to obtain a dictionary.

# Step 4. Display the dictionary.  One nice way to do this is to use the Python json module (already
#         imported).  You can pass the dictionary into json.dumps() and print this out.
