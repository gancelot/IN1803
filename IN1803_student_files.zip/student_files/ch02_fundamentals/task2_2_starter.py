"""

    task2_2_starter.py

"""
import json
from pprint import pprint

import click
import requests

base_url = 'http://localhost:8000'
path = '/api/invoices/'

default = 536365
# Step 1. You may optionally prompt the user for the invoice number
#         To do this, use the already imported click library:
#                invoice_num = click.prompt("your prompt here", default=default)

# Step 2. Construct the URL to access the API resource.  Include the server, path, and invoice number

# Step 3. Use requests to make a request to the server using the URL from step 2.  Perform a .json()
#         on the returned results to obtain a dictionary.

# Step 4. Display the dictionary.  One nice way to do this is to use the Python json module (already
#         imported).  You can pass the dictionary into json.dumps() and print this out or use pprint
#         (also, already imported)
