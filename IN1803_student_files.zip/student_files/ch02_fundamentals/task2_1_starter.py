"""

    task2_1_starter.py

    To test this out, for now, simply use a browser.
    Start the server and browser to:
    http://localhost:8000/api/invoices/536365

"""
from pathlib import Path

import uvicorn
from fastapi import FastAPI, HTTPException


# Step 1. create the main FastAPI() object, call it app

data_file = '../data/customer_purchases.csv'
data = [line.strip().split(',') for line in Path(data_file).open(encoding='unicode_escape')][1:]
print('Customer purchase data read.')

# Step 2. Create a decorator below that defines the URL mapping for this function.
#         The mapping URL path is up to you.
#         Use a path parameter (/{_____}) to allow an invoice number to be specified

def retrieve_invoice():
    # Step 3. Complete the line so that it searches data to find the matching invoice nums
    # Note: This can be similar to the celebrity example presented in the discussions.
    results = []

    # Step 4. Check if there were any results and if not raise an HTTPException.  Use a
    #         status_code of 404

    # Step 5. Complete the return statement to return our newly found data results.
    #         Create and return a dictionary of the results.
    return


# Step 6. Finish the uvicorn.run() statement to include the app object created in step 1.
uvicorn.run(, host='localhost', port=8000)
