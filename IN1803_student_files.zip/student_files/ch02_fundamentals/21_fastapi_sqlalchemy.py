"""

    21_fastapi_sqlalchemy.py

    Integrating SQLAlchemy with FastAPI.
    It uses Pydantic and SQLAlchemy classes.

"""
from pathlib import Path
import sys

import uvicorn
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from sqlalchemy import create_engine, Column
from sqlalchemy.orm import declarative_base, sessionmaker
from sqlalchemy.types import Float, Integer, String

db_url = Path(__file__).parents[1] / 'data/course_data.db'
if not db_url.exists():
    print(f'Database file does not exist at: {db_url}--exiting.', file=sys.stderr)
    sys.exit()

app = FastAPI()

engine = create_engine('sqlite:///' + str(db_url), echo=True)
Session = sessionmaker(bind=engine)
session = Session()

Base = declarative_base()


class Celebrity(BaseModel):
    name: str = ''
    pay: float = 0.0
    year: str = ''
    category: str = ''


class CelebrityModel(Base):
    __tablename__ = 'celebrity'
    id = Column('id', Integer, primary_key=True, autoincrement=True)
    name = Column(String(100))
    pay = Column(Float)
    year = Column(String(15))
    category = Column(String(50))

    def __init__(self, name: str, pay: float, year: str, category: str):
        self.name = name
        self.pay = pay
        self.year = year
        self.category = category

    def __str__(self):
        return f'{self.year} {self.name} {self.pay} {self.category}'

    def to_dict(self) -> dict:
        return {'id': self.id, 'name': self.name, 'pay': self.pay,
                'year': self.year, 'category': self.category}

    __repr__ = __str__


@app.get('/api/celebrities/id/{celeb_id}')
async def get_one_celebrity(celeb_id: int):
    celeb = session.get(CelebrityModel, celeb_id)
    if not celeb:
        raise HTTPException(status_code=404, detail=f'Celebrity not found.')
    return celeb.to_dict()


@app.get('/api/celebrities/{name}')
async def get_all_celebrities(name: str):
    celebs = session.query(CelebrityModel).filter(CelebrityModel.name.contains(name)).all()
    if not celebs:
        raise HTTPException(status_code=404, detail=f'No celebrities found.')
    return celebs


@app.post('/api/celebrities')
async def create_celebrity(new_celeb_request: Celebrity):
    try:
        new_celeb_db = CelebrityModel(**new_celeb_request.model_dump())
        session.add(new_celeb_db)
        session.commit()
        results = new_celeb_db.to_dict()
    except Exception as err:
        raise HTTPException(status_code=404, detail=f'Error creating celebrity: {err.args[0]}')

    return results


@app.put('/api/celebrities/id/{celeb_id}')
async def update_celebrity(celeb_id: int, updated_celeb: Celebrity):
    try:
        celeb = session.get(CelebrityModel, celeb_id)

        # actually behaves more like PATCH
        celeb.name = updated_celeb.name if updated_celeb.name else celeb.name
        celeb.year = updated_celeb.year if updated_celeb.year else celeb.year
        celeb.category = updated_celeb.category if updated_celeb.category else celeb.category
        celeb.pay = updated_celeb.pay if updated_celeb.pay else celeb.pay

        session.commit()

        results = celeb.to_dict()
    except Exception as err:
        raise HTTPException(status_code=404, detail=f'Error updating celebrity: {err.args[0]}')

    return results


@app.delete('/api/celebrities/id/{celeb_id}')
async def delete_celebrity(celeb_id: int):
    try:
        celeb = session.get(CelebrityModel, celeb_id)
        session.delete(celeb)
        session.commit()

        results = celeb.to_dict()
    except Exception as err:
        raise HTTPException(status_code=404, detail=f'Error removing celebrity: {err.args[0]}')

    return results


# or remove this and run from the command-line:  uvicorn 21_fastapi_sqlalchemy:app
uvicorn.run(app, host='localhost', port=8000)

