"""

    20_testing_post_using_pydantic_models.py

"""
import requests

base_url = 'http://localhost:8000'
path = '/api/celebrities/'
celeb_name = 'Kevin'

results = requests.get(f'{base_url}{path}{celeb_name}')
print(results.text)

print('posting:')
results = requests.post(f'{base_url}{path}'.strip('/'),
                        json={'name': celeb_name,
                              'category': 'Actors',
                              'pay': 3.0,
                              'year': 2024})
print(results.text)
print('Request body format:')
print(results.request.body)

print('putting:')
results = requests.put(f'{base_url}{path}{celeb_name}')
print(results.text)

print('deleting:')
results = requests.delete(f'{base_url}{path}{celeb_name}')
print(results.text)

print('get all:')
results = requests.get(f'{base_url}{path}'.strip('/'))
print(results.text)
