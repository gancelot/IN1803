"""

    task2_3_starter.py

    This version of the exercise will add in additional functions to handle
     the POST, GET (all), PUT, and DELETE methods.  It will also create a
     Pydantic Invoice Model...

     These new methods will not be completed yet only stubbed out for now.

"""
from pathlib import Path

import uvicorn
from fastapi import FastAPI, HTTPException
# Step 1. Import the Pydantic BaseModel class

data_file = '../data/customer_purchases.csv'
data = [line.strip().split(',') for line in Path(data_file).open(encoding='unicode_escape')][1:]
print('Customer purchase data read.')

app = FastAPI()


# Step 2.  Define the Invoice model class (a Pydantic model) using the fields
#          specified on our slide: stock_code (str), quantity (int), description (str),
#          invoice_date (str), unit_price (float), customer_id (str), and country (str).
#          Don't forget to inherit from BaseModel.


@app.get('/api/invoices/{invoice_num}')
def retrieve_invoice(invoice_num):
    results = [row[1:] for row in data if invoice_num == row[0]]

    if not results:
        raise HTTPException(status_code=404, detail='Invoice not found')

    return {'results': results}


# Step 3. Implement the POST method.  Call it create_invoice().  Add the @app.post() 
#         decorator above it (mapping to '/api/invoices').  Declare the function as
#         receiving an Invoice object.  Within the method (for now), simply
#         complete it by returning an object that indicates we are in the
#         post method.  Something like this will suffice: {'action': 'POST response'}

#         Also, respond with the invoice object data as well.  Do this by
#         passing the expanded invoice into the return dictionary, as follows:
#         **invoice.model_dump()



# Step 4. Provide a GET (all) path operation function called get_all_invoices().
#         Have it return a simple dictionary that indicates the function was called:
#         (e.g., {'action': 'GET (all) response'}


# Step 5. Provide a PUT path operation function called update_invoice().
#         Have it return a simple dictionary that indicates the function was called.
#         Don't forget the path parameter decorator.


# Step 5. Provide a DELETE path operation function called delete_invoice().
#         Have it return a simple dictionary that indicates the function was called.
#         Don't forget the path parameter decorator.

# Test it out by running this completed file first and then the provided task2_3_client.py file.

uvicorn.run(app, host='localhost', port=8000)
