"""

    14_using_pydantic.py

"""
import sys

from pydantic import BaseModel, ValidationError


class Celebrity(BaseModel):
    name: str
    pay: float
    year: int
    category: str


c1 = Celebrity(name='Oprah', pay=225.0, year=2005, category='Personalities')
c2 = Celebrity(name='Oprah', pay=225.0, year='2005', category='Personalities')
try:
    c3 = Celebrity(name='Oprah', pay=225.0, year='hello', category='Personalities')
except ValidationError as err:
    print(err, file=sys.stderr)
