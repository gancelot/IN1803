"""

    18_testing_post_as_json_send.py
    This source file should be used when running 17_post_as_json_data.py
    as the server.

"""
import requests

base_url = 'http://localhost:8000'
path = '/api/celebrities/'
celeb_name = 'Kevin'

print('posting:')
results = requests.post(f'{base_url}{path}'.strip('/'),
                        json={'name': celeb_name,
                              'category': 'Actors',
                              'pay': 3.0,
                              'year': 2024})
print(results.text)
print('Request body format:')
print(results.request.body)
