"""
    completed_invoice_multifile/app/resources.py

    Defines the API Resource classes.

"""
from flask import request, current_app as app
from flask_restx import Resource, Api

from .models import InvoiceModel
from .schema import invoice_schema, invoices_schema
from .database import db
from .errors import handle_error_processing_invoice

api = Api(app, prefix='/api')


def convert(value, typ, err_msg:str = 'Bad input value submitted.', code: int = 400):
    """Custom converter function.  Converts simple types such as str->int, str->float, etc.  Raises and returns an error if wrong."""
    try:
        print(f'converting: {value}, type: {typ}')
        new_value = typ(value)
    except Exception:
        print('conversion exception...')
        handle_error_processing_invoice(err_msg, code)
        return

    return new_value


class Invoices(Resource):
    page_size = 10

    def get(self):
        page = request.args.get('page') or '1'
        paged_invoices = InvoiceModel.query.paginate(int(page), self.page_size)
        return {'results': invoices_schema.dump(paged_invoices.items)}

    def post(self):
        invoice_no = request.form.get('invoice_no')
        stock_code = request.form.get('stock_code')
        quantity = convert(request.form.get('quantity'), int)
        description = request.form.get('description')
        invoice_date = request.form.get('invoice_date')
        unit_price = convert(request.form.get('unit_price'), float)
        customer_id = request.form.get('customer_id')
        country = request.form.get('country')

        new_purchase = InvoiceModel(invoice_no, stock_code, quantity, description,
                                    invoice_date, unit_price, customer_id, country)
        db.session.add(new_purchase)
        db.session.commit()

        return invoice_schema.jsonify(new_purchase)


class Invoice(Resource):
    def get(self, id):
        invoice = InvoiceModel.query.get(id)

        if not invoice:
            handle_error_processing_invoice()

        return invoice_schema.jsonify(invoice)

    def put(self, id):
        invoice_no = request.form.get('invoice_no')
        stock_code = request.form.get('stock_code')
        quantity = convert(request.form.get('quantity'), int)
        description = request.form.get('description')
        invoice_date = request.form.get('invoice_date')
        unit_price = convert(request.form.get('unit_price'), float)
        customer_id = request.form.get('customer_id')
        country = request.form.get('country')

        invoice = InvoiceModel.query.get(id)

        if not invoice:
            handle_error_processing_invoice()

        invoice.invoice_no = invoice_no
        invoice.stock_code = stock_code
        invoice.quantity = quantity
        invoice.description = description
        invoice.invoice_date = invoice_date
        invoice.unit_price = unit_price
        invoice.customer_id = customer_id
        invoice.country = country

        db.session.commit()

        return invoice_schema.jsonify(invoice)

    def patch(self, id):
        invoice = InvoiceModel.query.get(id)

        if not invoice:
            handle_error_processing_invoice()

        for item in request.form:           # checks each submitted field for existence
            if getattr(invoice, item):
                new_value = request.form.get(item)
                if item == 'quantity':
                    new_value = convert(new_value, int)
                elif item == 'unit_price':
                    new_value = convert(new_value, float)

                setattr(invoice, item, new_value)

        db.session.commit()

        return invoice_schema.jsonify(invoice)

    def delete(self, id):
        invoice = InvoiceModel.query.get(id)

        if not invoice:
            handle_error_processing_invoice()

        db.session.delete(invoice)
        db.session.commit()
        return invoice_schema.jsonify(invoice)


api.add_resource(Invoice, '/invoices/<id>')
api.add_resource(Invoices, '/invoices/')
