"""
    completed_invoice_multifile/app/schema.py

    Defines and instantiates Marshmallow schema.

"""
from flask_sqlalchemy import current_app as app
from flask_marshmallow import Marshmallow

ma = Marshmallow(app)


class InvoiceSchema(ma.Schema):
    class Meta:
        fields = ('id', 'invoice_no', 'stock_code', 'quantity', 'description', 'invoice_date', 'unit_price', 'customer_id', 'country')


invoice_schema = InvoiceSchema()
invoices_schema = InvoiceSchema(many=True)
