from flask_restx import abort


def handle_error_processing_invoice(message: str = f'The specified invoice doesn\'t exist.',
                                    error_code: int = 404):
    abort(error_code, message)
    return False
