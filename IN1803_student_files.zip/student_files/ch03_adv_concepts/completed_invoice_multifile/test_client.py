"""

    test_client.py

    Tests the multi-file invoice app.  First run app.py.

    Try changing the quantity for the PUT operation to a string, like 'six' instead of 6
"""
import requests

base_url = 'http://localhost:8051'
path = '/api/invoices/'

payload = {
    'invoice_no': '581588',
    'stock_code': '20961',
    'quantity': 3,
    'description': 'STRAWBERRY BATH SPONGE',
    'invoice_date': '2/2/2022',
    'unit_price': 2.46,
    'customer_id': 17850,
    'country': 'United Kingdom'
}

print('POSTing with new payload:')
results = requests.post(f'{base_url}{path}', data=payload)
new_invoice_id = results.json().get("id")
print(f'ID of new resource: {new_invoice_id}')
print(results.text)


bad_id = 0
print(f'GETting a bad id ({bad_id}):')
bad_results = requests.get(f'{base_url}{path}{bad_id}')
print(bad_results.text)

print(f'GETting invoice with id: {new_invoice_id}')
results = requests.get(f'{base_url}{path}{new_invoice_id}')
print(results.text)

payload['quantity'] = 6
print(f'PUTting with new quantity {payload["quantity"]}:')
results = requests.put(f'{base_url}{path}{new_invoice_id}', data=payload)
print(results.text)

description = 'LEMON SHAMPOO'
print(f'PATCHing new description: {description}:')
results = requests.patch(f'{base_url}{path}{new_invoice_id}', data={'description': description})
print(results.text)

print(f'DELETE-ing record with id: {new_invoice_id}')
results = requests.delete(f'{base_url}{path}{new_invoice_id}')
print(results.text)

print('GETting one page of results:')
results = requests.get(f'{base_url}{path}')
print(results.text)