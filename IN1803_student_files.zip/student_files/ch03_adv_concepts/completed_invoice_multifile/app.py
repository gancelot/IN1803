"""

    app.py
    The following demonstrates the Invoice API completed across multiple files.
    This uses the older_requirements.txt file.  A venv should be set up
    using the older_requirements.txt file packages.
"""
from ch03_adv_concepts.completed_invoice_multifile.app import create_app

app = create_app()

if __name__ == '__main__':
    app.run(host='localhost', port=8051)
