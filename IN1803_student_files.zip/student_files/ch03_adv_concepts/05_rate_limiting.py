"""

    05_rate_limiting.py

"""
from pathlib import Path
import sys

import uvicorn
from fastapi import FastAPI, HTTPException, Request, Response
from pydantic import BaseModel
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address
from sqlalchemy import create_engine, Column
from sqlalchemy.orm import declarative_base, sessionmaker
from sqlalchemy.types import Float, Integer, String

db_url = Path(__file__).parents[1] / 'data/course_data.db'
if not db_url.exists():
    print(f'Database file does not exist at: {db_url}--exiting.', file=sys.stderr)
    sys.exit()

limiter = Limiter(key_func=get_remote_address)
app = FastAPI()
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

engine = create_engine('sqlite:///' + str(db_url), echo=True)
Session = sessionmaker(bind=engine)
session = Session()

Base = declarative_base()


class Celebrity(BaseModel):
    name: str = ''
    pay: float = 0.0
    year: str = ''
    category: str = ''


class CelebrityModel(Base):
    __tablename__ = 'celebrity'
    id = Column('id', Integer, primary_key=True, autoincrement=True)
    name = Column(String(100))
    pay = Column(Float)
    year = Column(String(15))
    category = Column(String(50))

    def __init__(self, name: str, pay: float, year: str, category: str):
        self.name = name
        self.pay = pay
        self.year = year
        self.category = category

    def __str__(self):
        return f'{self.year} {self.name} {self.pay} {self.category}'

    def to_dict(self) -> dict:
        return {'id': self.id, 'name': self.name, 'pay': self.pay,
                'year': self.year, 'category': self.category}

    __repr__ = __str__


@app.get('/api/celebrities')
@limiter.limit('3/minute')
async def get_all_celebrities(request: Request, response: Response):
    return {'info': 'request allowed'}


uvicorn.run(app, host='localhost', port=8000)
