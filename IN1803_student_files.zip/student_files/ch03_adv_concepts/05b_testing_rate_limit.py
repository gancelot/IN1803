"""

    05b_testing_rate_limit
    This client should be used with the 05_rate_limiting.py server.

"""
import json

import requests

base_url = 'http://localhost:8000'
path = '/api/celebrities/'

for n in range(4):
    r = requests.get(f'{base_url}{path.rstrip('/')}')
    print(r.json())
    print()
