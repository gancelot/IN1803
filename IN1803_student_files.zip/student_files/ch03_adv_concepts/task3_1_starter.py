"""

    task3_1_starter.py

"""
import sys
from pathlib import Path

import uvicorn
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from sqlalchemy import create_engine, Column
from sqlalchemy.orm import declarative_base, sessionmaker
from sqlalchemy.types import Float, Integer, String

db_url = Path(__file__).parents[1] / 'data/course_data.db'
if not db_url.exists():
    print(f'Database file does not exist at: {db_url}--exiting.', file=sys.stderr)
    sys.exit()

app = FastAPI()

engine = create_engine('sqlite:///' + str(db_url), echo=True)
Session = sessionmaker(bind=engine)
session = Session()

Base = declarative_base()


class Invoice(BaseModel):
    invoice_num: str
    stock_code: str
    quantity: int
    description: str
    invoice_date: str
    unit_price: float
    customer_id: str
    country: str


class InvoiceModel(Base):
    __tablename__ = 'purchases'
    id = Column(Integer, primary_key=True, autoincrement=True)
    invoice_num = Column('InvoiceNo', String(30))
    stock_code = Column('StockCode', String(30))
    quantity = Column(Integer)
    description = Column(String(150))
    invoice_date = Column('InvoiceDate', String(50))
    unit_price = Column('UnitPrice', Float)
    customer_id = Column('CustomerID', String(50))
    country = Column(String(50))

    def __init__(self, invoice_num, stock_code, quantity, description, invoice_date,
                 unit_price, customer_id, country):
        super().__init__()
        self.invoice_num = invoice_num
        self.stock_code = stock_code
        self.quantity = quantity
        self.description = description
        self.invoice_date = invoice_date
        self.unit_price = unit_price
        self.customer_id = customer_id
        self.country = country

    def __str__(self):
        return f'({self.invoice_num}) {self.stock_code} Qty: {self.quantity} - {self.description}'

    def to_dict(self) -> dict:
        return {'id': self.id, 'invoice_num': self.invoice_num, 'stock_code': self.stock_code,
                'quantity': self.quantity, 'description': self.description, 'invoice_date': self.invoice_date,
                'unit_price': self.unit_price, 'customer_id': self.customer_id, 'country': self.country}

    __repr__ = __str__


@app.get('/api/invoices/{id}')
async def retrieve_invoice(id: int):
    invoice = session.get(InvoiceModel, id)
    if not invoice:
        raise HTTPException(status_code=404, detail=f'Invoice not found.')
    return invoice.to_dict()


@app.post('/api/invoices')
async def create_invoice(invoice_request: Invoice):
    try:
        new_invoice_db = InvoiceModel(**invoice_request.model_dump())
        session.add(new_invoice_db)
        session.commit()
        results = new_invoice_db.to_dict()
    except Exception as err:
        raise HTTPException(status_code=404, detail=f'Error creating invoice: {err.args[0]}')

    return results


# Step 1. Within the function paramater list below, define 2 parameters: limit and page.  Both are int types and
#         limit should have a default of 50, while page should have a default of 0.
@app.get('/api/invoices')
async def get_all_invoices():
    # Step 2. Modify the statement below to accept the limit and offset functions:
    #         session.query(InvoiceModel).limit(limit).offset(page * limit).all()
    invoices = session.query(InvoiceModel).all()
    if not invoices:
        raise HTTPException(status_code=404, detail=f'No invoices found.')
    return invoices


@app.put('/api/invoices/{id}')
async def update_invoice(id: int, updated_invoice: Invoice):
    try:
        invoice = session.get(InvoiceModel, id)

        invoice.invoice_num = updated_invoice.invoice_num if updated_invoice.invoice_num else invoice.invoice_num
        invoice.stock_code = updated_invoice.stock_code if updated_invoice.stock_code else invoice.stock_code
        invoice.quantity = updated_invoice.quantity if updated_invoice.quantity else invoice.quantity
        invoice.description = updated_invoice.description if updated_invoice.description else invoice.description
        invoice.invoice_date = updated_invoice.invoice_date if updated_invoice.invoice_date else invoice.invoice_date
        invoice.unit_price = updated_invoice.unit_price if updated_invoice.unit_price else invoice.unit_price
        invoice.customer_id = updated_invoice.customer_id if updated_invoice.customer_id else invoice.customer_id
        invoice.country = updated_invoice.country if updated_invoice.country else invoice.country

        session.commit()

        results = invoice.to_dict()
    except Exception as err:
        raise HTTPException(status_code=404, detail=f'Error updating invoice: {err.args[0]}')

    return results


@app.delete('/api/invoices/{id}')
async def delete_invoice(id: int):
    try:
        invoice = session.get(InvoiceModel, id)
        session.delete(invoice)
        session.commit()

        results = invoice.to_dict()
    except Exception as err:
        raise HTTPException(status_code=404, detail=f'Error removing invoice: {err.args[0]}')

    return results


uvicorn.run(app, host='localhost', port=8000)

