"""

    task3_1_client.py

"""
import requests

base_url = 'http://localhost:8000'
path = '/api/invoices/'

for n in range(0, 3):
    print(f'\ngetting page ({n}):')
    results = requests.get(f'{base_url}{path.rstrip('/')}', params={'limit': 5, 'page': n})
    print(results.text)
