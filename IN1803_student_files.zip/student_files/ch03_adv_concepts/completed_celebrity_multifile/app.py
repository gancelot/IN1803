"""

    app.py
    The following demonstrates the celebrity API completed across multiple files.

"""
from ch03_adv_concepts.completed_celebrity_multifile.app import create_app

app = create_app()

if __name__ == '__main__':
    app.run(host='localhost', port=8051)
