"""
    completed_celebrity_multifile/app/database.py

    Instantiates and makes available the SQLAlchemy plugin object (db).

"""
from flask import current_app as app
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy(app)
