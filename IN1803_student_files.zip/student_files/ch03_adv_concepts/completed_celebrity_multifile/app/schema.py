"""
    completed_celebrity_multifile/app/schema.py

    Defines and instantiates Marshmallow schema.

"""
from flask_sqlalchemy import current_app as app
from flask_marshmallow import Marshmallow

ma = Marshmallow(app)


class CelebritySchema(ma.Schema):
    class Meta:
        fields = ('id', 'name', 'year', 'pay', 'category')   # Fields to expose


celebrity_schema = CelebritySchema()
celebrities_schema = CelebritySchema(many=True)
