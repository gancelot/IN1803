from flask import request, current_app as app
from flask_restx import Resource, Api

from .models import CelebrityModel
from .schema import celebrity_schema, celebrities_schema
from .database import db
from .errors import handle_no_celebrity_exists_error

api = Api(app, prefix='/api')


class Celebrities(Resource):
    page_size = 10

    def get(self):
        page = request.args.get('page') or '1'
        paged_celebs = CelebrityModel.query.paginate(int(page), self.page_size)
        return {'results': celebrities_schema.dump(paged_celebs.items)}

    def post(self):
        name = request.form.get('name')
        year = request.form.get('year')
        category = request.form.get('category')
        pay = float(request.form.get('pay'))

        new_celeb = CelebrityModel(name, pay, year, category)
        db.session.add(new_celeb)
        db.session.commit()

        return celebrity_schema.jsonify(new_celeb)


class Celebrity(Resource):
    def get(self, id):
        celeb = CelebrityModel.query.get(id)

        if not celeb:
            handle_no_celebrity_exists_error()

        return celebrity_schema.jsonify(celeb)

    def delete(self, id):
        celeb = CelebrityModel.query.get(id)

        if not celeb:
            handle_no_celebrity_exists_error()

        db.session.delete(celeb)
        db.session.commit()
        return celebrity_schema.jsonify(celeb)

    def put(self, id):
        year = request.form.get('year')
        category = request.form.get('category')
        try:
            pay = float(request.form.get('pay'))
        except (ValueError, TypeError):
            pay = None

        celeb = CelebrityModel.query.get(id)

        if not celeb:
            handle_no_celebrity_exists_error()

        celeb.year = year
        celeb.category = category
        celeb.pay = pay

        db.session.commit()

        return celebrity_schema.jsonify(celeb)

    def patch(self, id):
        celeb = CelebrityModel.query.get(id)

        if not celeb:
            handle_no_celebrity_exists_error()

        if 'year' in request.form:
            celeb.year = request.form.get('year')
        if 'category' in request.form:
            celeb.category = request.form.get('category')
        if 'pay' in request.form:
            celeb.pay = float(request.form.get('pay'))

        db.session.commit()

        return celebrity_schema.jsonify(celeb)


api.add_resource(Celebrity, '/celebrities/<id>')
api.add_resource(Celebrities, '/celebrities/')
