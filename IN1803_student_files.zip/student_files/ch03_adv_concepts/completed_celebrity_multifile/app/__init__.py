"""
    completed_celebrity_multifile/app/__init__.py

    Defines the modules to be loaded containing various routes and plugin configurations.

"""
from flask import Flask


def create_app():
    app = Flask(__name__, instance_relative_config=False)
    app.config.from_object('ch03_adv_concepts.completed_celebrity_multifile.app.config.Config')

    with app.app_context():
        from . import resources
        from . import database
        from . import models
        from . import schema

    return app
