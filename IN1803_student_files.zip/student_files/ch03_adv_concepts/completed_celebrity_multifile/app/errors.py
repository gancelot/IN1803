from flask_restx import abort


def handle_no_celebrity_exists_error(message: str = f'The specified celebrity doesn\'t exist.',
                                     error_code: int = 404):
    abort(error_code, message)
    return False
