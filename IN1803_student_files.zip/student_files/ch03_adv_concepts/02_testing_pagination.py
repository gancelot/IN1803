"""

    02_testing_pagination.py

"""
import requests

base_url = 'http://localhost:8000'
path = '/api/celebrities/'
name = 'Tom'

for n in range(0, 3):
    print(f'\ngetting page ({n}):')
    results = requests.get(f'{base_url}{path}{name}', params={'limit': 3, 'page': n})
    print(f'Status: {results.status_code}')
    print(results.text)
