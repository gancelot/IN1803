"""

    05_asyncio.py - reading multiple files
                  The example reads 10 lines from 3 different files by scheduling process_data()
                  in the event loop 3 times.


"""
import asyncio
from itertools import islice
from pathlib import Path


async def process_data(filepath: Path):
    with filepath.open(encoding='utf-8') as f:
        for line in islice(f, 10):
            await asyncio.sleep(0)
            print(f'{filepath.name}: {line.strip()}')


async def main(files: list[str]):
    files = (Path(f'../data/{filename}') for filename in files)
    tasks = (process_data(f) for f in files)
    await asyncio.gather(*tasks)


data_files = ['car_crashes.csv', 'accounts.csv', 'contacts.dat']
asyncio.run(main(data_files))
