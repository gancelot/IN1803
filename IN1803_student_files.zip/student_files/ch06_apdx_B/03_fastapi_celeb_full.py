"""
    03_fastapi_celeb_full.py
    Reads celebrity data from a file, stores them in a list (celebs), then provides
    API methods: GET (one), POST, PUT, DELETE methods to manipulate a celebrity object
"""
from pathlib import Path

import uvicorn
from fastapi import FastAPI, HTTPException, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from pydantic import BaseModel


class Celebrity(BaseModel):
    celeb_id: int = None
    name: str = None
    salary: float = 0.0
    year: int = None
    type: str = None


celebs = []
datafile = Path(__file__).parents[1] / 'data/celebrity_100.csv'

with datafile.open(encoding='utf-8') as f:
    f.readline()
    for celeb_id, line in enumerate(f, 1):
        data = line.strip().split(',')
        data.insert(0, celeb_id)
        c = Celebrity(**dict(zip(Celebrity.model_fields, data)))
        celebs.append(c)
id_count = len(celebs)


app = FastAPI()


@app.get('/api/celebrities/{celeb_id}')
def get_celebs(celeb_id: int):
    matches = [celeb for celeb in celebs if celeb_id == celeb.celeb_id]
    if not matches:
        raise HTTPException(404, detail='No matching items.')
    return matches[0]


@app.post('/api/celebrities', status_code=status.HTTP_201_CREATED)
def create_celeb(celeb: Celebrity):
    global id_count
    id_count += 1
    celeb.celeb_id = id_count
    celebs.append(celeb)
    return celeb


@app.put('/api/celebrities/{celeb_id}')
def modify_celeb(celeb_id: int, celeb: Celebrity):
    celeb.celeb_id = celeb_id
    matches = [c for c in celebs if c.celeb_id == celeb.celeb_id]

    if not matches:
        raise HTTPException(404, detail='No matching items.')

    index = celebs.index(matches[0])
    celebs[index] = celeb
    return celebs[index]


@app.delete('/api/celebrities/{celeb_id}')
def remove_celeb(celeb_id: int):
    matches = [celeb for celeb in celebs if celeb_id == celeb.celeb_id]
    if not matches:
        raise HTTPException(404, detail='No matching items.')
    celebs.remove(matches[0])
    return matches[0]


@app.exception_handler(RequestValidationError)
async def custom_exception_handler(request: Request, exc: RequestValidationError):
    """Just showing how to handle custom errors that arise.  In this case,
       how to process a Pydantic ValidationError.  Note: A default handler exists, so
       this method is not necessary if default handling is sufficient."""
    root_error_info = exc.errors()[0]
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={
            'error': f'Your object contained invalid values.',
            'info': root_error_info.get('msg'),
            'input': root_error_info.get('input')
        }
    )


uvicorn.run(app, host='127.0.0.1', port=8000)
