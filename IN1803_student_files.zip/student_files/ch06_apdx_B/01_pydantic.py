from pathlib import Path

from pydantic import BaseModel


class Celebrity(BaseModel):
    name: str = None
    salary: float = 0.0
    year: int = None
    type: str = None


# Pydantic models must use keywords to instantiate
data = ['Oprah Winfrey', 225.0, 2005, 'Personalities']
c = Celebrity(name=data[0], salary=data[1], year=data[2], type=data[3])
print(c)

# another way to instantiate...
headers = Celebrity.model_fields
c = Celebrity(**dict(zip(headers, data)))
print(c)

# data values can be coerced...
data = ['Oprah Winfrey', '225.0', '2005', 'Personalities']
c = Celebrity(name=data[0], salary=data[1], year=data[2], type=data[3])
print(c)


# invalid types raise errors (uncomment these lines)...
# data = ['Oprah Winfrey', '225.0', 'some year', 'Personalities']
# c = Celebrity(name=data[0], salary=data[1], year=data[2], type=data[3])
# print(c)
