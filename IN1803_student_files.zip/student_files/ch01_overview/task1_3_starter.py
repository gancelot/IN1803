"""

    task1_3_starter.py

"""
import requests


urls = [
    'https://api.coinlore.net/api/tickers/?start=1&limit=5',
    'https://apimeme.com/meme?top=Tell%20Me%20More&bottom=About%20Chocolate',
    'https://datausa.io/api/data?drilldowns=State&measures=Population&year=latest'
]

# Step 1. Create a for-loop that iterates over each URL in urls above



# Step 2. Issue a get() request using the requests module.
#         Use either the .text attribute or the .json() method to print the returned responses




