"""

    task1_3_solution.py

"""
import requests


urls = [
    'https://api.coinlore.net/api/tickers/?start1&limit=5',
    'https://apimeme.com/meme?top=Tell%20Me%20More&bottom=About%20Chocolate',
    'https://datausa.io/api/data?drilldowns=State&measures=Population&year=latest'
]

for url in urls:
    r = requests.get(url)

    print(r.url)
    print('-'*len(r.url))
    print(r.text)            # or r.json()


# Not part of the requirements...
# For fun, here's how to capture the apimeme.com image into a file...
with open('meme_image.jpg', 'wb') as f:
    f.write(requests.get(urls[1]).content)
