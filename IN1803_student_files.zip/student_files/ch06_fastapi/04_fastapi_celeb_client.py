"""
    04_fastapi_celeb_client.py
    Accesses the FastAPI server (03_fastapi_celeb_full.py) making several requests:
    1. Creates a celebrity (Homer) using the provided payload
    2. Finds a celebrity with a wrong type of id (xyz)
    3. Finds a celebrity with an invalid id (0)
    4. Modifies the Homer celebrity with a PUT call.
    5. Retrieves the Homer celebrity with a GET call.
    6. Deletes the Homer celebrity with a DELETE call.
    7. Retrieves the Homer celebrity with a GET call (but no longer exists).
"""

import requests

payload = {
    'name': 'Homer Simpson',
    'salary': 1.25,
    'year': 2024,
    'type': 'Dad'
}

url = 'http://localhost:8000/api/celebrities'
result = requests.post(url, json=payload)
print(f'POST result: {result.text}')
new_celeb = result.json()


url = 'http://localhost:8000/api/celebrities/xyz'
result = requests.get(url)
print(f'GET xyz result: {result.text}')


url = 'http://localhost:8000/api/celebrities/0'
result = requests.get(url)
print(f'GET celeb_id=0 result: {result.text}')


url = f'http://localhost:8000/api/celebrities/{new_celeb['celeb_id']}'
new_celeb['salary'] = 2.50
result = requests.put(url, json=new_celeb)
print(f'PUT id={new_celeb['celeb_id']} result: {result.text}')


url = f'http://localhost:8000/api/celebrities/{new_celeb['celeb_id']}'
result = requests.get(url)
print(f'GET id={new_celeb['celeb_id']} result: {result.text}')


url = f'http://localhost:8000/api/celebrities/{new_celeb['celeb_id']}'
result = requests.delete(url)
print(f'DELETE id={new_celeb['celeb_id']} result: {result.text}')


url = f'http://localhost:8000/api/celebrities/{new_celeb['celeb_id']}'
result = requests.get(url)
print(f'GET id={new_celeb['celeb_id']} result: {result.text}')
