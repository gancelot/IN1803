from pydantic import BaseModel


class Celebrity(BaseModel):
    name: str = None
    salary: float = 0.0
    year: int = None
    type: str = None


# Pydantic models must use keywords to instantiate
c = Celebrity(name='Oprah Winfrey', salary=225.0, year=2005, type='Personalities')
print(f'Celebrity: {c}')

# another way to instantiate...
data = {
    'name': 'Oprah Winfrey',
    'salary': 225.0,
    'year': 2005,
    'type': 'Personalities'
}

c = Celebrity(**data)
print(f'Celebrity: {c}')

# data values can be coerced...
c = Celebrity(name='Oprah Winfrey', salary='225.0', year='2005', type='Personalities')
print(f'Celebrity: {c}')


# invalid types raise errors (uncomment these lines)...
# c = Celebrity(name='Oprah Winfrey', salary='225.0', year='some year', type='Personalities')
# print(f'Celebrity: {c}')
