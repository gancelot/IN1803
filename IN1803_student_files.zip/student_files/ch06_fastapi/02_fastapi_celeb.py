from pathlib import Path

import uvicorn
from fastapi import FastAPI
from pydantic import BaseModel


class Celebrity(BaseModel):
    name: str = None
    salary: float = 0.0
    year: int = None
    type: str = None


celebs = []
datafile = Path(__file__).parents[1] / 'data/celebrity_100.csv'

with datafile.open(encoding='utf-8') as f:
    f.readline()
    for line in f:
        data = line.strip().split(',')
        c = Celebrity(**dict(zip(Celebrity.model_fields, data)))
        celebs.append(c)


app = FastAPI()


@app.get('/api/celebrities/{name}', response_model=list[Celebrity])
def get_celebs(name: str):
    matches = [celeb for celeb in celebs if name.lower() in celeb.name.lower()]
    return matches


uvicorn.run(app, host='127.0.0.1', port=8000)
