"""

    01_basic_auth.py

"""
import requests
from requests.auth import HTTPBasicAuth
from bs4 import BeautifulSoup

page = 'https://testpages.eviltester.com/pages/auth/basic-auth/basic-auth-results.html'

username = 'authorized'
password = 'password001'

response = requests.get(page, auth=HTTPBasicAuth(username, password))
response.raise_for_status()

print('Status: ', response.status_code)
print('Raw response:\n', response.text)

soup = BeautifulSoup(response.text, 'html.parser')
print()
print(soup.select('.pageinfo p')[1].text)   # should display: 'You were  Authenticated'
