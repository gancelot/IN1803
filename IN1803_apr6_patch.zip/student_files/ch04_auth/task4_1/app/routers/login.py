"""

    Login Route

"""
from datetime import timedelta
from typing import Annotated

from fastapi import APIRouter, Form, HTTPException

from ..auth import authenticate_user, create_access_token, TOKEN_EXPIRATION
from ..auth_models import AuthCredentials, Token


# Step 1a. Add the APIRouter for login routes here


# Step 1b. Add a @router.post() decorator with a '/login' path to enable logging in

async def login_for_access_token(form_data: Annotated[AuthCredentials, Form()]) -> Token:
    print('in login')
    user = authenticate_user(form_data.username, form_data.password)

    if not user:
        raise HTTPException(status_code=401, detail='Incorrect login.', headers={'WWW-Authenticate': 'Bearer'})

    access_token = create_access_token(data={'sub': user.username}, expires_delta=timedelta(minutes=TOKEN_EXPIRATION))
    return Token(access_token=access_token, token_type='bearer')
