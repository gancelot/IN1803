"""

    task4_1/client.py
    This source file should be used when running the task4_1/app/main.py server.

"""
import click
import requests

base_url = 'http://localhost:8000'
get_all_url = f'{base_url}/api/invoices'

page = 0

try:
    print(f'Trying to access {get_all_url} without a token:')
    req1 = requests.get(get_all_url)
    print('Login status:', req1.status_code, req1.text)
except requests.exceptions.RequestException as err:
    print(f'Error fetching celebrities.\n{err}')
except Exception as err:
    print(f'Error parsing results.\n{err}')


print()
try:
    print(f'Trying to access {get_all_url} with invalid credentials:')
    req2 = requests.post(f'{base_url}/login', data={'username': 'admin', 'password': 'password'})
    print('Login status:', req2.status_code, req2.text)
except requests.exceptions.RequestException as err:
    print(f'Error fetching celebrities.\n{err}')
except Exception as err:
    print(f'Error parsing results.\n{err}')


print()
print('Getting all invoices...')
try:
    print('\nLogging in to /login with valid credentials:')

    # Step 3a.  Make a requests.post() call to f'{base_url}/login'.  Using the data=
    #          parameter, add the credentials for the admin user in the form of a dictionary.
    #          Note:  username=admin, password=admin
    #
    #          Call the return from the request, req3.

    print(req3.status_code, req3.text)
    token = req3.json().get('access_token')

    while True:
        print(f'Getting page {page}...')

        # Step 3b. In the requests.get() below, add a parameter called headers=
        #          and give it the token from our post request above as follows:
        #             {'Authorization': f'Bearer {token}'}
        response = requests.get(get_all_url,
                                params={'page': page})
        response.raise_for_status()
        records = response.json()
        print(f'Page: {page}')
        print('URL: ', response.url)
        page += 1
        print(records)
        if not click.confirm('Continue?', default=True):
            break

except requests.exceptions.RequestException as err:
    print(f'Error fetching invoices.\n{err}')
except Exception as err:
    print(f'Error parsing results.\n{err}')
