"""

    03_celeb_auth/app/main.py
    This server implements a structured multifile implementation.


"""
from fastapi import FastAPI
from app.middleware.rate_limit import limiter, RateLimitExceeded, _rate_limit_exceeded_handler, SlowAPIMiddleware

from app.routers import celebrities, login

app = FastAPI()
app.include_router(celebrities.router)
app.include_router(login.router)

app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
app.add_middleware(SlowAPIMiddleware)    # applies the default automatically
