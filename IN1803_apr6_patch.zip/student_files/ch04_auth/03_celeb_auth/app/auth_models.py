from sqlmodel import SQLModel, Field
from sqlalchemy import Column


class Token(SQLModel):
    access_token: str
    token_type: str


class TokenData(SQLModel):
    username: str | None = None


class AuthCredentials(SQLModel):
    username: str | None = None
    password: str | None = None


class User(SQLModel):
    username: str
    email: str | None = None
    full_name: str | None = None
    admin: bool = False


class UserInDB(User):
    hashed_password: str


class UserInDBModel(SQLModel, table=True):
    __tablename__ = 'user_auth'
    id: int = Field(default=None, primary_key=True)
    username: str
    full_name: str
    email: str
    hashed_password: str = Field(sa_column=Column('password'))
    admin: bool