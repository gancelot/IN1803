from datetime import datetime, timedelta, timezone
from typing import Annotated

import bcrypt
import jwt
from decouple import config
from fastapi import Depends, HTTPException, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jwt.exceptions import InvalidTokenError
from sqlalchemy import select

from .database import get_session_nondepends
from .auth_models import UserInDBModel, User, UserInDB, TokenData


SECRET_KEY = config('SECRET_KEY')
ALGORITHM = config('ALGORITHM')
TOKEN_EXPIRATION = config('TOKEN_EXPIRATION', cast=int)


def verify_password(plain_password, hashed_password):
    return bcrypt.checkpw(
        plain_password.encode('utf-8'),
        hashed_password.encode('utf-8')
    )


def get_password_hash(password: str):
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode("utf-8")


def get_user(username: str):
    with get_session_nondepends() as session:
        user = session.exec(select(UserInDBModel).filter(UserInDBModel.username == username)).first()

        if user:
            return UserInDB(**user[0].model_dump())
    return None


def authenticate_user(username: str, password: str):
    user = get_user(username)
    if not user:
        return False
    if not verify_password(password, user.hashed_password):
        return False
    return user


def encode_token(data_to_encode, secret_key: str = SECRET_KEY, algorithm: str = ALGORITHM) -> str:
    return jwt.encode(data_to_encode, secret_key, algorithm)


def decode_token(token, secret_key: str = SECRET_KEY, algorithm: str = ALGORITHM):
    return jwt.decode(token, secret_key, algorithms=[algorithm])


def create_access_token(data: dict, expires_delta: timedelta | None = None):
    to_encode = data.copy()
    if not expires_delta:
        expires_delta = timedelta(minutes=TOKEN_EXPIRATION)

    expire = datetime.now(timezone.utc) + expires_delta
    to_encode.update({"exp": expire})

    return encode_token(to_encode)


class JWTBearer(HTTPBearer):
    def __init__(self, auto_error: bool = True):
        super().__init__(auto_error=auto_error)

    async def __call__(self, request: Request):
        creds: HTTPAuthorizationCredentials = await super().__call__(request)
        if creds:
            if not creds.scheme == 'Bearer':
                raise HTTPException(status_code=403, detail='Invalid authentication scheme.')
            if not self.verify_token(creds.credentials):
                raise HTTPException(status_code=403, detail='Invalid token or expired token.')
            return creds.credentials
        else:
            raise HTTPException(status_code=403, detail='Invalid authorization code.')

    def verify_token(self, jwtoken: str) -> bool:
        token_valid: bool = False

        try:
            decode_token(jwtoken)
            token_valid = True
        except Exception:
            pass

        return token_valid


async def get_current_user(token: Annotated[str, Depends(JWTBearer())]):
    credentials_exception = HTTPException(status_code=401, detail='Could not validate credentials',
                                          headers={'WWW-Authenticate': 'Bearer'})
    try:
        payload = decode_token(token)
        username: str = payload.get('sub')
        if not username:
            raise credentials_exception
        token_data = TokenData(username=username)
    except InvalidTokenError:
        raise credentials_exception
    user = get_user(username=token_data.username)
    if user is None:
        raise credentials_exception
    return user


async def get_current_active_user(current_user: Annotated[User, Depends(get_current_user)]):
    return current_user
