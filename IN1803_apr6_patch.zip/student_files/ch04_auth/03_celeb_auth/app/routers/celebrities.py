from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlmodel import select

from ..auth import get_current_active_user
from ..auth_models import User
from ..database import SessionDep
from ..models import Celebrity

router = APIRouter()


@router.get('/api/celebrities/{celeb_id}')
async def get_celebrity(celeb_id: int, session: SessionDep) -> Celebrity:
    try:
        celebrity = session.get(Celebrity, celeb_id)
    except Exception as err:
        raise HTTPException(status_code=500, detail=f'Error getting celebrity: {err}')

    if not celebrity:
        raise HTTPException(status_code=404, detail=f'No celebrity with id: {celeb_id}')

    return celebrity


@router.get('/api/celebrities/name/{celeb_name}')
async def get_celebrity_by_name(celeb_name: str, session: SessionDep) -> list[Celebrity]:
    try:
        celebrities = session.exec(select(Celebrity).filter(Celebrity.name.contains(celeb_name)))
    except Exception as err:
        raise HTTPException(status_code=500, detail=f'Unable to retrieve celebrity name: {err}')

    if not celebrities:
        raise HTTPException(status_code=404, detail=f'No celebrity with name: {celeb_name}')

    return celebrities


@router.get('/api/celebrities')
async def get_all_celebrities(current_user: Annotated[User, Depends(get_current_active_user)],
                              session: SessionDep,
                              offset: int = 0,
                              limit: Annotated[int, Query(gt=0, le=50)] = 10) -> list[Celebrity]:
    try:
        celebrities = session.exec(select(Celebrity).offset(offset).limit(limit)).all()
    except Exception as err:
        raise HTTPException(status_code=500, detail=f'Error getting celebrities: {err}')

    return celebrities


@router.post('/api/celebrities')
async def create_celebrity(celeb: Celebrity, session: SessionDep) -> Celebrity:
    try:
        session.add(celeb)
        session.commit()
        session.refresh(celeb)
        return celeb
    except Exception as err:
        session.rollback()
        raise HTTPException(status_code=500, detail=f'Error creating new celebrity: {err}')


@router.put('/api/celebrities/{celeb_id}')
async def update_celebrity(celeb_id: int, celeb: Celebrity, session: SessionDep) -> Celebrity:
    try:
        celebrity = session.get(Celebrity, celeb_id)
    except Exception as err:
        raise HTTPException(status_code=400, detail=f'Invalid request. {err}')

    if not celebrity:
        raise HTTPException(status_code=404, detail=f'Celebrity with id: {celeb_id} not found.')

    for attr, new_value in celeb.model_dump().items():
        setattr(celebrity, attr, new_value)

    try:
        session.commit()
        session.refresh(celebrity)
        return celebrity
    except Exception as err:
        session.rollback()
        raise HTTPException(status_code=500, detail=f'Error updating celebrity.  {err}')


@router.delete('/api/celebrities/{celeb_id}')
async def delete_celebrity(celeb_id: int, session: SessionDep) -> dict:
    try:
        celebrity = session.get(Celebrity, celeb_id)
    except Exception as err:
        raise HTTPException(status_code=400, detail=f'Invalid request. {err}')

    if not celebrity:
        raise HTTPException(status_code=404, detail=f'Celebrity with id: {celeb_id} not found.')

    try:
        session.delete(celebrity)
        session.commit()
        return {'celebrity': celebrity.model_dump(), 'status': True}
    except Exception as err:
        session.rollback()
        raise HTTPException(status_code=500, detail=f'Error updating celebrity.  {err}')
