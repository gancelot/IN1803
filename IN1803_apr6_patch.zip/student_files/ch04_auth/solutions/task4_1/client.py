"""

    solutions/task4_1/client.py
    This source file should be used when running the solutions/task4_1/app/main.py server.

"""
import click
import requests

base_url = 'http://localhost:8000'
get_all_url = f'{base_url}/api/invoices'

page = 0

try:
    print(f'Trying to access {get_all_url} without a token:')
    req1 = requests.get(get_all_url)
    print('Login status:', req1.status_code, req1.text)
except requests.exceptions.RequestException as err:
    print(f'Error fetching celebrities.\n{err}')
except Exception as err:
    print(f'Error parsing results.\n{err}')


print()
try:
    print(f'Trying to access {get_all_url} with invalid credentials:')
    req2 = requests.post(f'{base_url}/login', data={'username': 'admin', 'password': 'password'})
    print('Login status:', req2.status_code, req2.text)
except requests.exceptions.RequestException as err:
    print(f'Error fetching celebrities.\n{err}')
except Exception as err:
    print(f'Error parsing results.\n{err}')


print()
print('Getting all invoices...')
try:
    print('\nLogging in to /login with valid credentials:')
    req3 = requests.post(f'{base_url}/login', data={'username': 'admin', 'password': 'admin'})
    print(req3.status_code, req3.text)
    token = req3.json().get('access_token')

    while True:
        print(f'Getting page {page}...')
        response = requests.get(get_all_url,
                                params={'page': page},
                                headers={'Authorization': f'Bearer {token}'})
        response.raise_for_status()
        records = response.json()
        print(f'Page: {page}')
        print('URL: ', response.url)
        page += 1
        print(records)
        if not click.confirm('Continue?', default=True):
            break

except requests.exceptions.RequestException as err:
    print(f'Error fetching invoices.\n{err}')
except Exception as err:
    print(f'Error parsing results.\n{err}')
