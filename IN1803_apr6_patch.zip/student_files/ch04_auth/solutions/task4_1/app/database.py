from contextlib import contextmanager
from pathlib import Path
from typing import Annotated

from fastapi import Depends
from sqlmodel import create_engine, Session

db_url = Path(__file__).parents[4] / 'data/course_data.db'
connect_args = {'check_same_thread': False}
engine = create_engine('sqlite:///' + str(db_url), connect_args=connect_args, echo=True)


@contextmanager
def get_session_nondepends():
    """Used in other functions outside of path operation functions"""
    with Session(engine) as session:
        yield session


def get_session():
    """Used in path operation functions"""
    with Session(engine) as session:
        yield session


SessionDep = Annotated[Session, Depends(get_session)]
