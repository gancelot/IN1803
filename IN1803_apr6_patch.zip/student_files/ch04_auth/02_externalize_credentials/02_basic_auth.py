"""

    02_basic_auth.py

"""
import requests
from bs4 import BeautifulSoup
from decouple import config
from requests.auth import HTTPBasicAuth


page = 'https://testpages.eviltester.com/pages/auth/basic-auth/basic-auth-results.html'

user = config('user')
password = config('password')

response = requests.get(page, auth=HTTPBasicAuth(user, password))
response.raise_for_status()

print('Status: ', response.status_code)
print('Raw response:\n', response.text)

soup = BeautifulSoup(response.text, 'html.parser')
print()
print(soup.select('.pageinfo p')[1].text)   # should display: 'You were  Authenticated'
