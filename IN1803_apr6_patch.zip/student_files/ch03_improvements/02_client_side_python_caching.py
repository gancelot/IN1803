
"""
    02_client_side_python_caching.py
    The example illustrates making 3 requests to a site.  The first request is
    cached on the client (for 10 seconds).
    The second request uses the cached version.  To determine this, examine the
    'date' header.
    The third request is made after the expiry and thus makes a request back to
    the server.

"""
import time
import requests_cache


with requests_cache.CachedSession('api_cache', expire_after=9) as session:
    response = session.get('http://example.com/')
    print(response.headers)
    time.sleep(2)
    response = session.get('http://example.com/')
    print('\n', response.headers)
    time.sleep(10)
    response = session.get('http://example.com/')
    print('\n', response.headers)
