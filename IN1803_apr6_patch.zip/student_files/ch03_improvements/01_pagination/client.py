"""

    01_pagination/client.py
    This source file should be used when running the 01_pagination/main.py server.
    It tests the use of pagination by supplying query string parameters.

"""
import click
import requests

base_url = 'http://localhost:8000'
path = '/api/celebrities/'

limit = 5
offset = 0

print()
print('Getting all celebrities (limits applied in the query string)...')
try:
    get_url = f'{base_url}/api/celebrities'

    while True:
        response = requests.get(get_url, params={'limit': limit, 'offset': offset})
        response.raise_for_status()
        records = response.json()
        print(f'Records ({offset}-{offset + limit})')
        print('URL: ', response.url)
        offset += limit
        print(records)
        if not click.confirm('Continue?', default=True):
            break

except requests.exceptions.RequestException as err:
    print(f'Error fetching celebrities.\n{err}')
except Exception as err:
    print(f'Error parsing results.\n{err}')
