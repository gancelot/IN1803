"""

    models.py
    Shown here are several variations on the Invoices model depending on the type
    of operation being performed.

"""
from sqlmodel import Field, SQLModel
from sqlalchemy import Column


class InvoiceBase(SQLModel):
    invoice_num: str = Field(sa_column=Column('InvoiceNo'))
    stock_code: str = Field(sa_column=Column('StockCode'))
    quantity: int
    description: str
    invoice_date: str = Field(sa_column=Column('InvoiceDate'))
    unit_price: float = Field(sa_column=Column('UnitPrice'))
    customer_id: str = Field(sa_column=Column('CustomerID'))
    country: str


class Invoice(InvoiceBase, table=True):
    __tablename__ = 'purchases'
    id: int | None = Field(default=None, primary_key=True)


class InvoiceCreate(InvoiceBase):
    pass


class InvoiceUpdate(InvoiceBase):
    id: int

