from typing import Annotated

from fastapi import APIRouter, HTTPException, Query
from sqlmodel import select

from ..database import SessionDep
from ..models import Invoice

router = APIRouter()


@router.get('/api/invoices/{invoice_id}')
async def get_invoice(invoice_id: int, session: SessionDep) -> Invoice:
    try:
        invoice: Invoice | None = session.get(Invoice, invoice_id)
    except Exception as err:
        raise HTTPException(status_code=500, detail=f'Error getting invoice: {err}')

    if not invoice:
        raise HTTPException(status_code=404, detail=f'No invoice with id: {invoice_id}')

    return invoice


@router.get('/api/invoices')
async def get_all_invoices(session: SessionDep, page: Annotated[int, Query(ge=0)] = 0) -> list[Invoice]:
    limit = 10
    try:
        invoices = session.exec(select(Invoice).offset(page*limit).limit(limit)).all()
    except Exception as err:
        raise HTTPException(status_code=500, detail=f'Error getting invoices: {err}')

    return invoices


@router.post('/api/invoices')
async def create_invoice(invoice: Invoice, session: SessionDep) -> Invoice:
    try:
        print(f'Inserting invoice: {invoice}')
        session.add(invoice)
        session.commit()
        session.refresh(invoice)
        return invoice
    except Exception as err:
        session.rollback()
        raise HTTPException(status_code=500, detail=f'Error creating new invoice: {err}')


@router.put('/api/invoices/{invoice_id}')
async def update_invoice(invoice_id: int, updated_invoice: Invoice, session: SessionDep) -> Invoice:
    try:
        invoice = session.get(Invoice, invoice_id)
    except Exception as err:
        raise HTTPException(status_code=400, detail=f'Invalid request. {err}')

    if not invoice:
        raise HTTPException(status_code=404, detail=f'Invoice with id: {invoice_id} not found.')

    for attr, new_value in updated_invoice.model_dump().items():
        setattr(invoice, attr, new_value)

    try:
        session.commit()
        session.refresh(invoice)
        return invoice
    except Exception as err:
        session.rollback()
        raise HTTPException(status_code=500, detail=f'Error updating invoice.  {err}')


@router.delete('/api/invoices/{invoice_id}')
async def delete_invoice(invoice_id: int, session: SessionDep) -> dict:
    try:
        invoice = session.get(Invoice, invoice_id)
    except Exception as err:
        raise HTTPException(status_code=400, detail=f'Invalid request. {err}')

    if not invoice:
        raise HTTPException(status_code=404, detail=f'Invoice with id: {invoice_id} not found.')

    try:
        session.delete(invoice)
        session.commit()
        return {'invoice': invoice.model_dump(), 'status': True}
    except Exception as err:
        session.rollback()
        raise HTTPException(status_code=500, detail=f'Error updating invoice.  {err}')
