"""

    solutions/task3_1/app/main.py
    This server implements a structured multifile implementation.


"""
from fastapi import FastAPI
from app.middleware.rate_limit import limiter, RateLimitExceeded, _rate_limit_exceeded_handler, SlowAPIMiddleware

from app.routers import invoices


app = FastAPI()
app.include_router(invoices.router)

app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
app.add_middleware(SlowAPIMiddleware)    # applies the default automatically
