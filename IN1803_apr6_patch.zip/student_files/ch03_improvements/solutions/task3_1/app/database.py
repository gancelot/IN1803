from pathlib import Path
from typing import Annotated

from fastapi import Depends
from sqlmodel import create_engine, Session

db_url = Path(__file__).parents[4] / 'data/course_data.db'
engine = create_engine('sqlite:///' + str(db_url), echo=True)


def get_session():
    with Session(engine) as session:
        yield session


SessionDep = Annotated[Session, Depends(get_session)]
