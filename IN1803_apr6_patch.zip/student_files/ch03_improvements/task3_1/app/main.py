"""

    task3_1/app/main.py
    This server implements a structured multifile implementation.


"""
from fastapi import FastAPI
from app.middleware.rate_limit import limiter, RateLimitExceeded, _rate_limit_exceeded_handler, SlowAPIMiddleware

# Step 1a. Import the invoices.py module here using from app.routers import invoices


app = FastAPI()
# Step 1b. Use app.include_router() and pass the invoices module's router variable here


# Step 5a. Add the limiter to the app.state object

app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
# Step 5b. Add a middleware to the app to apply the rate limiter
