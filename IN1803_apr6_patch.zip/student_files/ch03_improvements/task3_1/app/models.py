"""

    models.py

"""
from sqlmodel import Field, SQLModel
from sqlalchemy import Column


class Invoice(SQLModel, table=True):
    __tablename__ = 'purchases'
    id: int | None = Field(default=None, primary_key=True)
    invoice_num: str = Field(sa_column=Column('InvoiceNo'))
    stock_code: str = Field(sa_column=Column('StockCode'))
    quantity: int
    description: str
    invoice_date: str = Field(sa_column=Column('InvoiceDate'))
    unit_price: float = Field(sa_column=Column('UnitPrice'))
    customer_id: str = Field(sa_column=Column('CustomerID'))
    country: str

# Step 6. Break the Invoice class into 4 classes:
# a) Rename Invoice to InvoiceBase
# b) Make an new Invoice class below it, have it inherit from InvoiceBase
# c) Move the two __tablename__ and id: int   lines into the Invoice class
# d) Move the table=True from InvoiceBase to Invoice
# e) Create an InvoiceCreate() class that inherits from InvoiceBase but only has pass in it
# f) Create an InvoiceUpdate() class that inherits from InvoiceBase but only has id: int in it


