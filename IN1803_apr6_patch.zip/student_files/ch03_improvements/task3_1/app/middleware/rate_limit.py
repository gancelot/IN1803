from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware
from slowapi.util import get_remote_address


# Step 4. Instantiate the Limiter, pass key_func=get_remote_address and
#         default_limits=['3/minute'] to limit requests to 3 per minute
