"""

    task3_1/client.py
    This source file should be used when running the task3_1/app/main.py server.

"""
import click
import requests

base_url = 'http://localhost:8000'
path = '/api/invoices/'

page = 0

print()
print('Getting all invoices (page number sent, limit hardcoded on server to 10)...')
try:
    get_url = f'{base_url}/api/invoices'

    while True:
        response = requests.get(get_url, params={'page': page})
        response.raise_for_status()
        records = response.json()
        print(f'Page: {page}')
        print('URL: ', response.url)
        page += 1
        print(records)
        if not click.confirm('Continue?', default=True):
            break

except requests.exceptions.RequestException as err:
    print(f'Error fetching invoices.\n{err}')
except Exception as err:
    print(f'Error parsing results.\n{err}')
