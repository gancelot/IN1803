"""

    models.py
    Shown here are several variations on the Celebrity model depending on the type
    of operation being performed.

"""
from sqlmodel import Field, SQLModel


class CelebrityBase(SQLModel):
    name: str
    pay: float
    year: str
    category: str


class Celebrity(CelebrityBase, table=True):
    id: int | None = Field(default=None, primary_key=True)


class CelebrityCreate(CelebrityBase):
    pass


class CelebrityUpdate(CelebrityBase):
    id: int
