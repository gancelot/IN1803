# This would contain any functions, such as auth-related
# functions that are used in a Depends() call elsewhere.
