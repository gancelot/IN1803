"""

    03_rate_limit/main.py
    This server implements a default 3 per minute request limit or 1 per minute for
    the single get_celebrity() function call.


"""
from pathlib import Path
from typing import Annotated

from fastapi import FastAPI, HTTPException, Depends, Query
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware
from slowapi.util import get_remote_address
from sqlmodel import create_engine, Field, select, Session, SQLModel


class Celebrity(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key=True)  # int | None equivalent to Optional[int]
    name: str
    pay: float
    year: str
    category: str


db_url = Path(__file__).parents[2] / 'data/course_data.db'
engine = create_engine('sqlite:///' + str(db_url), echo=True)


def get_session():
    with Session(engine) as session:
        yield session


SessionDep = Annotated[Session, Depends(get_session)]

app = FastAPI()

limiter = Limiter(key_func=get_remote_address, default_limits=['3/minute'])
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
app.add_middleware(SlowAPIMiddleware)               # applies the default automatically


@app.get('/api/celebrities/{celeb_id}')
async def get_celebrity(celeb_id: int, session: SessionDep) -> Celebrity:
    try:
        celebrity = session.get(Celebrity, celeb_id)
    except Exception as err:
        raise HTTPException(status_code=500, detail=f'Error getting celebrity: {err}')

    if not celebrity:
        raise HTTPException(status_code=404, detail=f'No celebrity with id: {celeb_id}')

    return celebrity


@app.get('/api/celebrities/name/{celeb_name}')
async def get_celebrity_by_name(celeb_name: str, session: SessionDep) -> list[Celebrity]:
    try:
        celebrities = session.exec(select(Celebrity).filter(Celebrity.name.contains(celeb_name)))
    except Exception as err:
        raise HTTPException(status_code=500, detail=f'Unable to retrieve celebrity name: {err}')

    if not celebrities:
        raise HTTPException(status_code=404, detail=f'No celebrity with name: {celeb_name}')

    return celebrities


@app.get('/api/celebrities')
async def get_all_celebrities(session: SessionDep,
                              offset: int = 0,
                              limit: Annotated[int, Query(gt=0, le=50)] = 10) -> list[Celebrity]:
    try:
        celebrities = session.exec(select(Celebrity).offset(offset).limit(limit)).all()
    except Exception as err:
        raise HTTPException(status_code=500, detail=f'Error getting celebrity: {err}')

    return celebrities


@app.post('/api/celebrities')
async def create_celebrity(celeb: Celebrity, session: SessionDep) -> Celebrity:
    try:
        session.add(celeb)
        session.commit()
        session.refresh(celeb)
        return celeb
    except Exception as err:
        session.rollback()
        raise HTTPException(status_code=500, detail=f'Error creating new celebrity: {err}')


@app.put('/api/celebrities/{celeb_id}')
async def update_celebrity(celeb_id: int, celeb: Celebrity, session: SessionDep) -> Celebrity:
    try:
        celebrity = session.get(Celebrity, celeb_id)
    except Exception as err:
        raise HTTPException(status_code=400, detail=f'Invalid request. {err}')

    if not celebrity:
        raise HTTPException(status_code=404, detail=f'Celebrity with id: {celeb_id} not found.')

    for attr, new_value in celeb.model_dump().items():
        setattr(celebrity, attr, new_value)

    try:
        session.commit()
        session.refresh(celebrity)
        return celebrity
    except Exception as err:
        session.rollback()
        raise HTTPException(status_code=500, detail=f'Error updating celebrity.  {err}')


@app.delete('/api/celebrities/{celeb_id}')
async def delete_celebrity(celeb_id: int, session: SessionDep) -> dict:
    try:
        celebrity = session.get(Celebrity, celeb_id)
    except Exception as err:
        raise HTTPException(status_code=400, detail=f'Invalid request. {err}')

    if not celebrity:
        raise HTTPException(status_code=404, detail=f'Celebrity with id: {celeb_id} not found.')

    try:
        session.delete(celebrity)
        session.commit()
        return {'celebrity': celebrity.model_dump(), 'status': True}
    except Exception as err:
        session.rollback()
        raise HTTPException(status_code=500, detail=f'Error updating celebrity.  {err}')
