"""

    task2_1/main.py

    To test this out, for now, simply use a browser.
    Start the server and browse to:
    http://localhost:8000/api/invoices/536365

"""
import sys

import uvicorn
from fastapi import FastAPI, HTTPException


datafile = '../../data/customer_purchases.csv'


def acquire_data() -> list[list]:
    data = []
    try:
        with open(datafile, encoding='unicode_escape') as f:
            for line in f:
                data.append(line.strip().split(','))
        print('Customer invoice data read.')

        return data
    except Exception as err:
        print(f'Error reading data from file: {err}')
        sys.exit(1)


invoices = acquire_data()

# Step 1. create the main FastAPI() object, call it app



# Step 2. Create a decorator below that defines the URL mapping for this function.
#         The mapping URL path is up to you.
#         Use a path parameter (/{_____}) to allow an invoice number to be specified

def retrieve_invoice():
    # Step 3. Complete the line so that it searches data to find the matching invoice nums
    # Note: This can be similar to the celebrity example presented in the discussions.
    results = []

    # Step 4. Check if there were any results and if not raise an HTTPException.  Use a
    #         status_code of 404

    # Step 5. Complete the return statement to return our newly found data results.
    #         Create and return a dictionary of the results.
    return
