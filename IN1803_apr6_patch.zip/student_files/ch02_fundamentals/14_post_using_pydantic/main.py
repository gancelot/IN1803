"""

    14_post_using_pydantic/main.py

    This implements the POST method within FastAPI.  It illustrates data submitted
    as JSON data in the body of the HTTP request.
    This version, however, uses a Pydantic model to capture data.

"""
from pathlib import Path
from typing import Annotated

from fastapi import FastAPI, HTTPException, Depends
from sqlmodel import Field, Session, SQLModel, create_engine


class Celebrity(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key=True)  # int | None equivalent to Optional[int]
    name: str
    pay: float
    year: str
    category: str


db_url = Path(__file__).parents[2] / 'data/course_data.db'
engine = create_engine('sqlite:///' + str(db_url), echo=True)


def get_session():
    with Session(engine) as session:
        yield session


SessionDep = Annotated[Session, Depends(get_session)]

app = FastAPI()


@app.get('/api/celebrities/{celeb_id}')
async def get_celebrity(celeb_id: int, session: SessionDep) -> Celebrity:
    try:
        celebrity = session.get(Celebrity, celeb_id)
    except Exception as err:
        raise HTTPException(status_code=500, detail=f'Error getting celebrity: {err}')

    if not celebrity:
        raise HTTPException(status_code=404, detail=f'No celebrity with id: {celeb_id}')

    return celebrity


@app.post('/api/celebrities')
async def create_celebrity(celeb: Celebrity, session: SessionDep) -> Celebrity:
    try:
        session.add(celeb)
        session.commit()
        session.refresh(celeb)
        return celeb
    except Exception as err:
        session.rollback()
        raise HTTPException(status_code=500, detail=f'Error creating new celebrity: {err}')