"""

    14_post_using_pydantic/client.py
    This source file should be used when running the 14_post_using_pydantic/main.py server.

"""
import requests

base_url = 'http://localhost:8000'
path = '/api/celebrities/'
celeb_name = 'Kevin'

print('posting:')
form_data = {'name': celeb_name, 'category': 'Actors', 'pay': 3.0, 'year': 2024}
url = f'{base_url}{path}'.strip('/')
try:
    response = requests.post(url, json=form_data)
    response.raise_for_status()

    print('Returned from server:')
    print(response.text)
    print('Request body format:')
    print(response.request.body)

except requests.exceptions.RequestException as err:
    print(f'Error posting celebrity.\n{err}')
    exit(1)


print()
print('Fetching newly added celebrity details...')

try:
    new_obj_id = response.json().get('id')
    print(f'New celebrity created with ID: {new_obj_id}')
    get_url = f'{base_url}/api/celebrities/{new_obj_id}'
    get_response = requests.get(get_url)
    get_response.raise_for_status()

    print(f'Fetched celebrity details: {get_response.json()}')
except requests.exceptions.RequestException as err:
    print(f'Error fetching celebrity details.\n{err}')
except Exception as err:
    print(f'Error parsing celebrity results.\n{err}')
