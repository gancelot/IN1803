"""

    10_using_pydantic.py

"""
import sys

from pydantic import BaseModel, ValidationError, Field


class Celebrity(BaseModel):
    name: str = Field(default='John Doe', min_length=3)
    pay: float = Field(default=0.0, ge=0.0, lt=1000000.0)
    year: int
    category: str


c1 = Celebrity(name='Oprah', pay=225.0, year=2005, category='Personalities')
c2 = Celebrity(name='Oprah', pay=225.0, year='2005', category='Personalities')
try:
    c3 = Celebrity(name='Oprah', pay=225.0, year='hello', category='Personalities')
except ValidationError as err:
    print(err, file=sys.stderr)
