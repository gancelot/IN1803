"""

    task2_2_solution.py

"""
from pprint import pprint

import click
import requests

base_url = 'http://localhost:8000'
path = '/api/invoices/'


def get_invoice(invoice_num: str) -> dict | None:
    url = f'{base_url}{path}{invoice_num}'
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        return response.json()
    except requests.HTTPError:
        if response.status_code == 404:
            print(f'Invoice {invoice_num} not found.')
        else:
            print(f'HTTP error {response.status_code}: {response.text}')
    except requests.RequestException as err:
        print(f'Request failed: {err}')


if __name__ == '__main__':
    default = '536365'
    invoice_num = click.prompt('Enter invoice number to retrieve', default=default)

    result = get_invoice(invoice_num)
    if result:
        print('\nInvoice data:')
        pprint(result)
