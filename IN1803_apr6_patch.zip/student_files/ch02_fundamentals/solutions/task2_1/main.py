"""

    solutions/task2_1/main.py

    To test this out, for now, simply use a browser.
    Start the server and browse to:
    http://localhost:8000/api/invoices/536365


"""
import sys

import uvicorn
from fastapi import FastAPI, HTTPException


datafile = '../../../data/customer_purchases.csv'


def acquire_data() -> list[list]:
    data = []
    try:
        with open(datafile, encoding='unicode_escape') as f:
            for line in f:
                data.append(line.strip().split(','))
        print('Customer invoice data read.')

        return data
    except Exception as err:
        print(f'Error reading data from file: {err}')
        sys.exit(1)


invoices = acquire_data()
app = FastAPI()


@app.get('/api/invoices/{invoice_num}')
async def retrieve_invoice(invoice_num: str):
    results = [row[1:] for row in invoices if invoice_num == row[0]]

    if not results:
        raise HTTPException(status_code=404, detail=f'Invoice {invoice_num} not found.')

    return {'results': results, 'invoice_num': invoice_num}


if __name__ == '__main__':
    # can run uvicorn within the script without starting from the command-line with fastapi dev
    uvicorn.run(app, host='localhost', port=8000)
