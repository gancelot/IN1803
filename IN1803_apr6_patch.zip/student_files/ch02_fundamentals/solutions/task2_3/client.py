"""

    solutions/task2_3/client.py
    This source file should be used when running the solutions/task2_3/main.py server.

"""
import requests

base_url = 'http://localhost:8000'
path = '/api/invoices/'

payload = {
    'invoice_num': '581590',
    'stock_code': '20961',
    'quantity': 3,
    'description': 'STRAWBERRY BATH SPONGE',
    'invoice_date': '2/2/2022',
    'unit_price': 2.46,
    'customer_id': '17850',
    'country': 'United Kingdom'
}

print('posting:')
url = f'{base_url}{path}'.strip('/')
try:
    response = requests.post(url, json=payload)
    response.raise_for_status()

    print('Returned from server:')
    print(response.text)
    print('Request body format:')
    print(response.request.body)

except requests.exceptions.RequestException as err:
    print(f'Error posting invoice.\n{err}')
    exit(1)


print()
print('Fetching newly added invoice line item details...')

try:
    new_obj_id = response.json().get('id')
    print(f'New invoice line item created with ID: {new_obj_id}')
    get_url = f'{base_url}/api/invoices/{new_obj_id}'
    get_response = requests.get(get_url)
    get_response.raise_for_status()

    print(f'Fetched invoice line item details: {get_response.json()}')
except requests.exceptions.RequestException as err:
    print(f'Error fetching invoice details.\n{err}')
except Exception as err:
    print(f'Error parsing invoice results.\n{err}')
