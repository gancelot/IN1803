"""

    solutions/task2_3/main.py

    This implements the POST and GET methods within FastAPI.  It incorporates
    SQLModel to communicate with the database.

"""
from pathlib import Path
from typing import Annotated

from fastapi import FastAPI, HTTPException, Depends
from sqlalchemy import Column
from sqlmodel import Field, Session, SQLModel, create_engine


class Invoice(SQLModel, table=True):
    __tablename__ = 'purchases'
    id: int | None = Field(default=None, primary_key=True)  # int | None equivalent to Optional[int]
    invoice_num: str = Field(sa_column=Column('InvoiceNo'))
    stock_code: str = Field(sa_column=Column('StockCode'))
    quantity: int
    description: str
    invoice_date: str = Field(sa_column=Column('InvoiceDate'))
    unit_price: float = Field(sa_column=Column('UnitPrice'))
    customer_id: str = Field(sa_column=Column('CustomerID'))
    country: str


db_url = Path(__file__).parents[3] / 'data/course_data.db'
engine = create_engine('sqlite:///' + str(db_url), echo=True)


def get_session():
    with Session(engine) as session:
        yield session


SessionDep = Annotated[Session, Depends(get_session)]

app = FastAPI()


@app.get('/api/invoices/{invoice_id}')
async def get_invoice(invoice_id: int, session: SessionDep) -> Invoice:
    try:
        invoice: Invoice | None = session.get(Invoice, invoice_id)
    except Exception as err:
        raise HTTPException(status_code=500, detail=f'Error getting invoice: {err}')

    if not invoice:
        raise HTTPException(status_code=404, detail=f'No invoice with id: {invoice_id}')

    return invoice


@app.post('/api/invoices')
async def create_invoice(invoice: Invoice, session: SessionDep) -> Invoice:
    try:
        print(f'Inserting invoice: {invoice}')
        session.add(invoice)
        session.commit()
        session.refresh(invoice)
        return invoice
    except Exception as err:
        session.rollback()
        raise HTTPException(status_code=500, detail=f'Error creating new invoice: {err}')
