"""

    solutions/task2_4/client.py
    This source file should be used when running the solutions/task2_4/main.py server.

"""
import requests

base_url = 'http://localhost:8000'
path = '/api/invoices/'

payload = {
    'invoice_num': '581590',
    'stock_code': '20961',
    'quantity': 3,
    'description': 'STRAWBERRY BATH SPONGE',
    'invoice_date': '2/2/2022',
    'unit_price': 2.46,
    'customer_id': '17850',
    'country': 'United Kingdom'
}

print('posting:')
url = f'{base_url}{path}'.strip('/')
try:
    response = requests.post(url, json=payload)
    response.raise_for_status()

    print('Returned from server:')
    print(response.text)
    print('Request body format:')
    print(response.request.body)

except requests.exceptions.RequestException as err:
    print(f'Error posting invoice.\n{err}')
    exit(1)


print()
print('Fetching newly added invoice line item details...')

try:
    new_obj_id = response.json().get('id')
    print(f'New invoice line item created with ID: {new_obj_id}')
    get_url = f'{base_url}/api/invoices/{new_obj_id}'
    get_response = requests.get(get_url)
    get_response.raise_for_status()

    print(f'Fetched invoice line item details: {get_response.json()}')
except requests.exceptions.RequestException as err:
    print(f'Error fetching invoice item details.\n{err}')
except Exception as err:
    print(f'Error parsing invoice item results.\n{err}')


print()
print('Using retrieved invoice item details to update...')
try:
    updated_payload = get_response.json()
    updated_payload['quantity'] = 10
    updated_payload['invoice_date'] = '12/12/2025'
    updated_payload['unit_price'] = 3.00

    put_url = f'{base_url}{path}{new_obj_id}'
    put_response = requests.put(put_url, json=updated_payload)
    put_response.raise_for_status()

    print(f'Invoice item details updated: {put_response.json()}')
except requests.exceptions.RequestException as err:
    print(f'Error modifying invoice item details.\n{err}')


print()
print('Deleting recently updated invoice item...')
try:
    delete_url = f'{base_url}{path}{new_obj_id}'
    delete_response = requests.delete(delete_url)
    delete_response.raise_for_status()

    print(f'Results of delete: {delete_response.json()}')
except requests.exceptions.RequestException as err:
    print(f'Error modifying invoice item details.\n{err}')


print()
print('Fetching recently deleted invoice item...')
try:
    get_url = f'{base_url}{path}{new_obj_id}'
    get_response = requests.get(get_url)
    get_response.raise_for_status()

    print(f'Fetched invoice item details: {get_response.json()}')
except requests.exceptions.RequestException as err:
    print(f'Error fetching invoice item details.\n{err}')
except Exception as err:
    print(f'No invoice item results.  Object not found.\n{err}')


print()
print('Getting all invoices (display output limited)...')
try:
    get_url = f'{base_url}/api/invoices'
    get_response = requests.get(get_url)
    get_response.raise_for_status()

    size_limit = 50
    print(f'Fetching all invoices: {get_response.json()[:size_limit]}')
except requests.exceptions.RequestException as err:
    print(f'Error fetching all invoices.\n{err}')
except Exception as err:
    print(f'Error parsing results.\n{err}')
