"""

    task2_3/main.py

    This implements the POST and GET methods within FastAPI.  It incorporates
    SQLModel to communicate with the database.

"""
from pathlib import Path
from typing import Annotated

from fastapi import FastAPI, HTTPException, Depends
from sqlalchemy import Column
# Step 1. Import the sqlmodel Field, Session, SQLModel class, and create_engine


# Step 2. Add the inheritance and table=True fields to the Invoice() class.  Add the
#         other fields: invoice_num (str), stock_code (str), quantity (int), description (str),
#                       invoice_date (str), unit_price (float), customer_id (str), country (str).
class Invoice():
    __tablename__ = 'purchases'
    id: int | None = Field(default=None, primary_key=True)



db_url = Path(__file__).parents[2] / 'data/course_data.db'
engine = create_engine('sqlite:///' + str(db_url), echo=True)


def get_session():
    with Session(engine) as session:
        yield session


SessionDep = Annotated[Session, Depends(get_session)]

app = FastAPI()

# Step 4. Complete the GET path operation function by addint the decorator
# (which maps to '/api/invoices/{invoice_id}') and adding the invoice_id
# parameter and session dependency parameters.  Also add the Invoice return annotation.

async def get_invoice():
    try:
        invoice: Invoice | None = session.get(Invoice, invoice_id)
    except Exception as err:
        raise HTTPException(status_code=500, detail=f'Error getting invoice: {err}')

    if not invoice:
        raise HTTPException(status_code=404, detail=f'No invoice with id: {invoice_id}')

    return invoice


# Step 3. Create the POST path operation function below.
#     a) Add the POST decorator and map to '/api/invoices'
#     b) Add the invoice and session parameters to the function, also add the Invoice return annotation

async def create_invoice():
    try:
        # c) Add code to insert a new invoice into the database using the session object
    except Exception as err:
        session.rollback()
        raise HTTPException(status_code=500, detail=f'Error creating new invoice: {err}')
