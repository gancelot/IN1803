"""

    task2_4/main.py

    This task asks you to implement the GET (all), PUT, and DELETE HTTP methods.

"""
from pathlib import Path
from typing import Annotated

from fastapi import FastAPI, HTTPException, Depends
from sqlalchemy import Column
from sqlmodel import create_engine, Field, select, Session, SQLModel


class Invoice(SQLModel, table=True):
    __tablename__ = 'purchases'
    id: int | None = Field(default=None, primary_key=True)  # int | None equivalent to Optional[int]
    invoice_num: str = Field(sa_column=Column('InvoiceNo'))
    stock_code: str = Field(sa_column=Column('StockCode'))
    quantity: int
    description: str
    invoice_date: str = Field(sa_column=Column('InvoiceDate'))
    unit_price: float = Field(sa_column=Column('UnitPrice'))
    customer_id: str = Field(sa_column=Column('CustomerID'))
    country: str


db_url = Path(__file__).parents[2] / 'data/course_data.db'
engine = create_engine('sqlite:///' + str(db_url), echo=True)


def get_session():
    with Session(engine) as session:
        yield session


SessionDep = Annotated[Session, Depends(get_session)]

app = FastAPI()


@app.get('/api/invoices/{invoice_id}')
async def get_invoice(invoice_id: int, session: SessionDep) -> Invoice:
    try:
        invoice: Invoice | None = session.get(Invoice, invoice_id)
    except Exception as err:
        raise HTTPException(status_code=500, detail=f'Error getting invoice: {err}')

    if not invoice:
        raise HTTPException(status_code=404, detail=f'No invoice with id: {invoice_id}')

    return invoice


# Step 1. Create the GET (all) path operation function
#         a) Define the path operation decorator with '/api/invoices'
#         b) Add the session as a parameter to the function
#         c) Select all the invoices using session.exec(select(Invoice)).all(), set an invoices variable to it.

async def get_all_invoices() -> list[Invoice]:
    try:

    except Exception as err:
        raise HTTPException(status_code=500, detail=f'Error getting invoices: {err}')

    return invoices




@app.post('/api/invoices')
async def create_invoice(invoice: Invoice, session: SessionDep) -> Invoice:
    try:
        print(f'Inserting invoice: {invoice}')
        session.add(invoice)
        session.commit()
        session.refresh(invoice)
        return invoice
    except Exception as err:
        session.rollback()
        raise HTTPException(status_code=500, detail=f'Error creating new invoice: {err}')


# Step 2. Create the PUT path operation function
#         a) Define the path operation decorator with '/api/invoices/{invoice_id}'
#         b) Add the invoice_id (int), updated_invoice (Invoice), and session (SessionDep) as parameters to the function

async def update_invoice() -> Invoice:
    try:
        # c) Use session.get() to retrieve the specified invoice by id,
        #    set a return variable, call it invoice.

    except Exception as err:
        raise HTTPException(status_code=400, detail=f'Invalid request. {err}')

    if not invoice:
        raise HTTPException(status_code=404, detail=f'Invoice with id: {invoice_id} not found.')

    # d) Transfer attributes from the updated_invoice to the invoice
    #    Use a for loop to iterate over the attributes and values of the updated_invoice
    #    Call setattr to update invoice attributes.
    #   for attr, new_value in updated_invoice.model_dump().items():
    #       setattr(invoice, attr, new_value)


    try:
        session.commit()
        session.refresh(invoice)
        return invoice
    except Exception as err:
        session.rollback()
        raise HTTPException(status_code=500, detail=f'Error updating invoice.  {err}')


# Step 3. Create the DELETE path operation function
#         a) Define the path operation decorator with '/api/invoices/{invoice_id}'
#         b) Add the invoice_id (int) and session (SessionDep) as parameters to the function

async def delete_invoice() -> dict:
    invoice = None
    try:
        # c) Use session.get() to retrieve the specified invoice by id,
        #    set a return variable, call it invoice.

    except Exception as err:
        raise HTTPException(status_code=400, detail=f'Invalid request. {err}')

    if not invoice:
        raise HTTPException(status_code=404, detail=f'Invoice with id: {invoice_id} not found.')

    try:
        # d) do a session.delete() passing in the invoice

        session.commit()
        return {'invoice': invoice.model_dump(), 'status': True}
    except Exception as err:
        session.rollback()
        raise HTTPException(status_code=500, detail=f'Error updating invoice.  {err}')
