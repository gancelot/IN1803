"""

    task2_2_starter.py

"""
from pprint import pprint

import click
import requests

base_url = 'http://localhost:8000'
path = '/api/invoices/'


def get_invoice(invoice_num: str) -> dict | None:
    # Step 2. Construct the URL to access the API resource.  Include the server, path, and invoice number

    try:
        # Step 3. Use requests to make a request to the server using the URL from step 2.
        # Perform a raise_for_status() on the response.
        # Return the response.json()


    except requests.HTTPError:
        if response.status_code == 404:
            print(f'Invoice {invoice_num} not found.')
        else:
            print(f'HTTP error {response.status_code}: {response.text}')
    except requests.RequestException as err:
        print(f'Request failed: {err}')


if __name__ == '__main__':
    default = '536365'
    # Step 1. Prompt the user for the invoice number.
    #         To do this, use the already imported click library:
    #                invoice_num = click.prompt("your prompt here", default=default)

    #         Call the get_invoice() function passing the invoice_num, get the results back



    # Step 4. Display the dictionary.  One nice way to do this is to use the Python json module (already
    #         imported).  You can pass the dictionary into json.dumps() and print this out or use pprint
    #         (also, already imported)

