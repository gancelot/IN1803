"""

    05_path_operation_functions/main.py

"""
import sys

from fastapi import FastAPI

datafile = '../../data/celebrity_100.csv'


def acquire_data() -> list[list]:
    data = []
    try:
        with open(datafile, encoding='utf-8') as f:
            for line in f:
                data.append(line.strip().split(','))
        print('Celebrity data read.')

        return data
    except Exception as err:
        print(f'Error reading data from file: {err}')
        sys.exit(1)


celebrities = acquire_data()
app = FastAPI()


@app.get('/api/celebrities/{celeb_name}')
async def get_celebrities(celeb_name: str):

    return {
            'greeting': f'Hi there {celeb_name}',
            'other': ['stuff1', 'stuff2'],
            'more': {'level': 2}
           }
