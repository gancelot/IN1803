"""

    04_simple_api/main.py

"""
from fastapi import FastAPI


app = FastAPI()
