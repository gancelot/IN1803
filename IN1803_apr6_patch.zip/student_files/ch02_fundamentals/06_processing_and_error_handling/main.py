"""

    06_processing_and_error_handling/main.py

"""
import sys

from fastapi import FastAPI, HTTPException

datafile = '../../data/celebrity_100.csv'


def acquire_data() -> list[list]:
    data = []
    try:
        with open(datafile, encoding='utf-8') as f:
            for line in f:
                data.append(line.strip().split(','))
        print('Celebrity data read.')

        return data
    except Exception as err:
        print(f'Error reading data from file: {err}')
        sys.exit(1)


celebrities = acquire_data()
app = FastAPI()


@app.get('/api/celebrities/{celeb_name}')
async def get_celebrities(celeb_name: str):

    results = [celeb for celeb in celebrities if celeb_name.lower() == celeb[0].lower()]
    if not results:
        raise HTTPException(status_code=404, detail=f'No celebrities with name: {celeb_name}')

    return {
            'search_val': celeb_name,
            'results': results
           }
