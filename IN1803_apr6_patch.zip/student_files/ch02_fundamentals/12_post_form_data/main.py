"""

    12_post_form_data/main.py

    This implements the POST method within FastAPI.  While not complete, it illustrates the method stub
    as if data was submitted as FORM data in the body of the HTTP request.
    (Note: see the data= attribute of the POST request in the subsequent source file).

"""
import sys
from typing import Annotated

from fastapi import FastAPI, Form, HTTPException

datafile = '../../data/celebrity_100.csv'


def acquire_data() -> list[list]:
    data = []
    try:
        with open(datafile, encoding='utf-8') as f:
            for line in f:
                data.append(line.strip().split(','))
        print('Celebrity data read.')

        return data
    except Exception as err:
        print(f'Error reading data from file: {err}')
        sys.exit(1)


celebrities = acquire_data()
app = FastAPI()


@app.get('/api/celebrities/{celeb_name}')
async def get_celebrities(celeb_name: str):

    results = [celeb for celeb in celebrities if celeb_name.lower() == celeb[0].lower()]
    if not results:
        raise HTTPException(status_code=404, detail=f'No celebrities with name: {celeb_name}')

    return {
            'search_val': celeb_name,
            'results': results
           }


@app.post('/api/celebrities')
async def create_celebrity(name: Annotated[str, Form()],
                           pay: Annotated[float, Form()],
                           year: Annotated[int, Form()],
                           category: Annotated[str, Form()]):
    return {'action': 'POST response',
            'name': name, 'pay': pay, 'year': year, 'category': category}
