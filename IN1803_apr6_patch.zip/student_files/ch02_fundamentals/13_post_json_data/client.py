"""

    13_post_json_data/client.py
    This source file should be used when running the 13_post_json_data/main.py server.

"""
import requests

base_url = 'http://localhost:8000'
path = '/api/celebrities/'
celeb_name = 'Kevin'

print('posting:')
form_data = {'name': celeb_name, 'category': 'Actors', 'pay': 3.0, 'year': 2024}
url = f'{base_url}{path}'.strip('/')
response = requests.post(url, json=form_data)

print('Returned from server:')
print(response.text)
print('Request body format:')
print(response.request.body)
