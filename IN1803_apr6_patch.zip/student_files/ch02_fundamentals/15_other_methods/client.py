"""

    15_other_methods/client.py
    This source file should be used when running the 15_other_methods/main.py server.

"""
import requests

base_url = 'http://localhost:8000'
path = '/api/celebrities/'
celeb_name = 'Kevin'

print('posting:')
form_data = {'name': celeb_name, 'category': 'Actors', 'pay': 3.0, 'year': 2024}
url = f'{base_url}{path}'.strip('/')
try:
    response = requests.post(url, json=form_data)
    response.raise_for_status()

    print('Returned from server:')
    print(response.text)
    print('Request body format:')
    print(response.request.body)

except requests.exceptions.RequestException as err:
    print(f'Error posting celebrity.\n{err}')
    exit(1)


print()
print('Fetching newly added celebrity details...')
try:
    new_obj_id = response.json().get('id')
    print(f'New celebrity created with ID: {new_obj_id}')
    get_url = f'{base_url}{path}{new_obj_id}'
    get_response = requests.get(get_url)
    get_response.raise_for_status()

    print(f'Fetched celebrity details: {get_response.json()}')
except requests.exceptions.RequestException as err:
    print(f'Error fetching celebrity details.\n{err}')
except Exception as err:
    print(f'Error parsing celebrity results.\n{err}')


print()
print('Using retrieved celebrity details to update...')
try:
    updated_payload = get_response.json()
    updated_payload['name'] = 'Kevin Bacon'
    updated_payload['pay'] = 5.0
    updated_payload['year'] = 2023

    put_url = f'{base_url}{path}{new_obj_id}'
    put_response = requests.put(put_url, json=updated_payload)
    put_response.raise_for_status()

    print(f'Celebrity details updated: {put_response.json()}')
except requests.exceptions.RequestException as err:
    print(f'Error modifying celebrity details.\n{err}')


print()
print('Deleting recently updated celebrity...')
try:
    delete_url = f'{base_url}{path}{new_obj_id}'
    delete_response = requests.delete(delete_url)
    delete_response.raise_for_status()

    print(f'Results of delete: {delete_response.json()}')
except requests.exceptions.RequestException as err:
    print(f'Error modifying celebrity details.\n{err}')

print()
print('Fetching recently deleted celebrity...')
try:
    get_url = f'{base_url}{path}{new_obj_id}'
    get_response = requests.get(get_url)
    get_response.raise_for_status()

    print(f'Fetched celebrity details: {get_response.json()}')
except requests.exceptions.RequestException as err:
    print(f'Error fetching celebrity details.\n{err}')
except Exception as err:
    print(f'No celebrity results.  Object not found.\n{err}')


print()
print('Getting all celebrities (output limited)...')
try:
    get_url = f'{base_url}/api/celebrities'
    get_response = requests.get(get_url)
    get_response.raise_for_status()

    size_limit = 50
    print(f'Fetching all celebrities: {get_response.json()[:size_limit]}')
except requests.exceptions.RequestException as err:
    print(f'Error fetching all celebrities.\n{err}')
except Exception as err:
    print(f'Error parsing results.\n{err}')


celeb_id = 10000
print()
print('Testing a bad celebrity ID...')
print(f'Bad ID: {celeb_id}')
try:
    r = requests.get(f'{base_url}{path}{celeb_id}')
    print(f'(Status: {r.status_code}), URL: {r.url}')
    print(r.json())
except Exception as err:
    print(f'Error testing bad celebrity ID.\n{err}')


print()
celeb_name = 'Kevin'
print('Finding Celebrities by name...')
print(f'Name: {celeb_name}')
try:
    r = requests.get(f'{base_url}/api/celebrities/name/{celeb_name}')
    print(f'(Status: {r.status_code}), URL: {r.url}')
    print(r.json())
except Exception as err:
    print(f'Error finding celebrity by name. Name: {celeb_name}.\n{err}')


print()
celeb_name = 'XYZ'
print('Finding Celebrities by name...(bad name)...')
print(f'Name: {celeb_name}')
try:
    r = requests.get(f'{base_url}/api/celebrities/name/{celeb_name}')
    print(f'(Status: {r.status_code}), URL: {r.url}')
    print(r.json())
except Exception as err:
    print(f'Error finding celebrity by name. Name: {celeb_name}.\n{err}')